#the goal of this script is to produce an ordination plot for all deserts and treatments together


setwd()
speciesdataset<-read.csv("seedbank_ghousecountdata_species.csv")
attribute<-read.csv("seedbank_attribute_spreadsheet.csv")
specieslist<-read.csv("seedbank_greenhouse_specieslist.csv")
View(attribute)

library(tidyverse)
#install.packages("dplyr")
library(dplyr)
library(lubridate)
library(ggplot2)
library(vegan)
library(reshape2)
#install.packages("ggrepel")
library(ggrepel)
library(gridExtra)
#install.packages("ggthemes")
library(ggthemes)
library(RColorBrewer)
#install.packages("indicspecies")
library(indicspecies)


##################################### DATA PREP ###############################################
#create a "uniqueid" column in the attribute table that consists of the plot name and microsite
View(attribute)
att.1<-attribute%>%
  unite(unique, fullplot_name, overstory, sep = "-", remove = FALSE)%>%
  dplyr::select(sample, unique)
View(att.1)
#use the one above to merge with removal data to add UNIQUE ID field

att.2<-attribute%>%
  unite(unique, fullplot_name, overstory, sep = "-", remove = FALSE)

att.3<-att.2%>%
  dplyr::select(unique, desert, TSF2, burn, overstory, fire_name, plot_num)%>%
  distinct(.)

att.3$DST<-paste(att.3$desert,att.3$fire_name, att.3$TSF2, sep="-")
att.3$DT<-paste(att.3$desert,att.3$TSF2, sep="-")
att.3$DO<-paste(att.3$desert,att.3$overstory,sep="-")
att.3$TO<-paste(att.3$TSF2,att.3$overstory, sep="-")

View(att.3)
#use att.3 as final "environmental data"

###########removal data prep

#append usda codes to the removals data
species.1<-full_join(speciesdataset, specieslist, by="sp_id")
sum(species.1$count)#check 5416 is right!
#View(species.1)

#select only the sample, species ID and count columns from the original removals spreadsheet
#group all species ID's by sample and sum the "count" column for each sample x species
species.2<-species.1%>%
  dplyr::select(sample, count, USDA)
#verify the # total number of germinants is correct
sum(species.2$count) #yep, check!
#View(species.2)
str(species.2)
#sum the count for each USDA code for each sample
species.3<-species.2%>%
  group_by(sample, USDA)%>%
  summarise_at(vars(count), funs(sum))
sum(species.3$count) #yep, check!
#View(species.3)

#calculate seeds/m2
#convert each "count" to seeds/m2
#20,000 cm3/m2 for a 2 cm depth divided by our total sample size - 169.65 cm3 for a 6 cm by 2 cm core
#create the function(below)
seedstom2<-function(x){
  x*117.9
  
}

#create a new column that multiplies the no. seesd per sample or "count" by the function to give seeds/m2
species.3$seedsm2<-seedstom2(species.3$count)
str(species.3)
sum(species.3$count) #yep, check!

#remove "count" column
species.4<-species.3
species.4$count<-NULL

#convert this data to "wide" sample by species format
str(species.4)
species.5<-spread(species.4, USDA, seedsm2)
View(species.5)


#append the "unique column from att.1 to removal3 so we have all 540 samples plus unique ID
species.6<-full_join(species.5, att.1, by="sample")

#replace all NAs with 0
str(species.6)
species.7<-species.6 %>%
  mutate_at(c(2:91), ~replace(., is.na(.), 0))
View(species.7)

#remove "count" column
species.8<-species.7
species.8$count<-NULL

#remove sample 77
View(species.8)
str(species.8)
species.8<-species.8[-c(533),]

#average the counts for each UNIQUE ID
species.9<-species.8%>%
  group_by(unique)%>%
  summarise_all("mean")

View(species.9)

#remove the sample column 
species.9$sample <- NULL

####################### FINAL DATASETS FOR REVIEW #########################

#final species data
species.final<-species.9
str(species.final)
View(species.final)

#final attribute data
att.final<-att.3
str(att.final)
View(att.final)

########################### separate each desert #######################

#subset species matrices
###when subsetting...i'm not removing species that don't exist for a specific desert
#for example..there are 90 unique taxa TOTAL across all 4 deserts, when I subset the CH, i'm leaving
#all 90 in there...even though maybe only 30/90 are actually present in the CH samples...

species.ch<-species.final[grep("CH", species.final$unique), ]
str(species.ch)
species.cp<-species.final[grep("MV", species.final$unique), ]
str(species.cp)
species.gb<-species.final[grep("GB", species.final$unique), ]
str(species.gb)
species.so<-species.final[grep("SO", species.final$unique), ]
str(species.so)

#subset ATTRIBUTE matrices

att.ch<-att.final[grep("CH", att.final$unique), ]
#View(att.ch)
att.cp<-att.final[grep("MV", att.final$unique), ]
#View(att.cp)
att.gb<-att.final[grep("GB", att.final$unique), ]
#View(att.gb)
att.so<-att.final[grep("SO", att.final$unique), ]



############################## quick ord with all deserts combined

all<-vegdist(species.final[, -1], method="bray", binary=FALSE)
NMDS.scree <- function(x) { 
  plot(rep(1, 10), replicate(10, metaMDS(x, autotransform = F, k = 1)$stress), xlim = c(1, 10),ylim = c(0, 0.30), xlab = "# of Dimensions", ylab = "Stress", main = "NMDS stress plot")
  for (i in 1:10) {
    points(rep(i + 1,10),replicate(10, metaMDS(x, autotransform = F, k = i + 1)$stress))
  }
}

NMDS.scree(all)
#at k=2 dimensions, stress is ~.1 so 2 dimensions should be OK

#wihtout seed - with DISTANCE MATRIX seed - 2 solutions after 67 tries
all.NMDS.dist <- metaMDS(all,k = 2, trymax = 100, trace = FALSE)
all.NMDS.dist
all.NMDS.dist$stress #0.0969831
stressplot(all.NMDS.dist)

#with DISTANCE MATRIX seed - 2 solutions after 67 tries
set.seed(124)
all.NMDS.dist.1 <- metaMDS(all,k = 2, trymax = 100, trace = FALSE)
all.NMDS.dist.1
all.NMDS.dist.1$stress # 0.09698456   
stressplot(all.NMDS.dist.1)

#ord plot using nmds with distance matrix
par(mfrow=c(1,1))
alldist<-ordiplot(all.NMDS.dist, type="points")
ordiellipse(alldist, att.final$DT, col=1:13,lwd=3, label=TRUE)
###USING A DISTANCE MATRIX MAKES A DIFFERENCE

#make a fancy plot following the code from here
#https://stackoverflow.com/questions/47516448/how-to-get-ordispider-like-clusters-in-ggplot-with-nmds
scrs<-scores(all.NMDS.dist, display="sites")
scrs<-cbind(as.data.frame(scrs), DT=att.final$DT)
cent<-aggregate(cbind(NMDS1, NMDS2)~DT, data=scrs, FUN=mean)
segs <- merge(scrs, setNames(cent, c('DT','oNMDS1','oNMDS2')),
              by = 'DT', sort = FALSE)

View(scrs)
str(scrs)
str(cent)
str(segs)

#re-order the variables for points/centroids/lines to match desired legend

scrs$DT<-factor(scrs$DT, levels=c("CH-15C", "CH-15F", "CH-30C", "CH-30F",
                                  "SO-15C", "SO-15F", "SO-30C", "SO-30F",
                                  "GB-15C", "GB-15F", "GB-30C", "GB-30F",
                                  "CP-15F", "CP-30F", "CP-con"))
cent$DT<-factor(cent$DT, levels=c("CH-15C", "CH-15F", "CH-30C", "CH-30F",
                                  "SO-15C", "SO-15F", "SO-30C", "SO-30F",
                                  "GB-15C", "GB-15F", "GB-30C", "GB-30F",
                                  "CP-15F", "CP-30F", "CP-con"))
segs$DT<-factor(segs$DT, levels=c("CH-15C", "CH-15F", "CH-30C", "CH-30F",
                                  "SO-15C", "SO-15F", "SO-30C", "SO-30F",
                                  "GB-15C", "GB-15F", "GB-30C", "GB-30F",
                                  "CP-15F", "CP-30F", "CP-con"))

levels(scrs$DT)
#plot data

alldesordplot.1<-ggplot(scrs, aes(x = NMDS1, y = NMDS2, colour = DT)) +
  geom_segment(data = segs,
               mapping = aes(xend = oNMDS1, yend = oNMDS2)) + # spiders
  geom_point(data = cent, size = 2) +                         # centroids
  geom_point() +                                              # sample scores
  theme_bw()+
  theme(panel.background = element_rect(colour = "black",size = 1, linetype = "solid"),
        legend.position="bottom",
        legend.text = element_text(size = 8), 
        legend.title.align = 0.5,
        legend.title = element_text(size = 8),
        axis.title = element_text(size=8),
        axis.text = element_text(size = 7), plot.title=element_text(size=9),
        plot.margin = unit(c(-1,1,-1,1), "mm"))+
  guides(col = guide_legend(nrow = 4,title.position = "top"))+
  scale_colour_discrete(name="Desert:Time-Since-Fire",
                        labels=c("CH-Short TSF(con)", "CH-Short TSF(fire)", "CH-Long TSF(con)", "CH-Long TSF(fire)", 
                                 "SO-Short TSF(con)", "SO-Short TSF(fire)", "SO-Long TSF(con)", "SO-Long TSF(fire)",
                                 "GB-Short TSF(con)", "GB-Short TSF(fire)", "GB-Long TSF(con)", "GB-Long TSF(fire)",
                                 "CP-Short TSF(fire)", "CP-Long TSF(fire)","CP-Control"
                                 )) +
  
  coord_fixed()


alldesordplot.1

#install.packages("patchwork")
library(patchwork)

tiff("tiff_ALLDESERTord_fig3_20220108.tiff", units="in", width=6, height=5, res=300)

alldesordplot.1

dev.off()

