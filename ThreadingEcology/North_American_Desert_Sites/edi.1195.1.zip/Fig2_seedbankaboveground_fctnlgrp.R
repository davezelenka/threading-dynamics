#The goal of this script is to summarize SEED BANK & aboveground data
#by functional grou by desert and BURN STATUS using proportions
#producing figure 2

#producing this figure had multiple steps.

#first, the aboveground data had to be combined and prepared using this script:
#aboveground_functionalgroup_prepcode

#then the seed bank data had to be prepared using this code:
#seedbank_functionalgroup_prepcode

#then, the two datasets had to be merged and count (for seedbank) and cover (for aboveground) had to be converted to proprotions
#this was easier to do in excel as you'll see in the notes below

#code and data for this prep work are provided

setwd()

sb<-read.csv("seedbank_fctnlgrpsummary.csv")
ag<-read.csv("aboveground_fctnlgrpsummary.csv")
sb_prop<-read.csv("sbagcombinedaboveground_fctngrpsummary_withproportions.csv")


View(sb)
View(ag)

library(tidyverse)
#install.packages("dplyr")
library(dplyr)
library(lubridate)
library(reshape2)
library(tidyr)
library(Rmisc)
library(ggplot2)
library(gridExtra)

##Following the prep work codes, the remaining steps are:

#1. each dataset has a slightly different # of column so for each, select only columns needed to make figures
#we also need column names to match so for each dataset, change "count" or "cover" to "ctcvr"

sb.1<-sb%>%
  dplyr::select(desert, sample, data_type, fctngrp, burn, count,overstory)%>%
  rename_at("count", ~"ctcvr")
View(sb.1)
sum(sb.1$ctcvr) #just triple checking the counts add up correctly!

ag.1<-ag%>%
  dplyr::select(desert, sample, data_type, fctngrp, burn, cover,overstory)%>%
  rename_at("cover", ~"ctcvr")
View(ag.1)

#2. merge with seed bank dataset

function_all<-rbind(ag.1, sb.1)
#view(function_all)

#3. "spread" functional groups back out so that they're each their own column - should have 6 total
#then, we should have a total of 1079 records (540 for ag, 539 for sb)

function_all.1<-function_all%>%
  spread(fctngrp, ctcvr)

View(function_all.1)

#the result is beautiful, but we need to delete the "na" column (which is a product of the SB samples
#that had 0 germinants), replace NA's with 0, and remove both rows for sample 77

#delete the NA column
function_all.1$`<NA>`<-NULL
View(function_all.1)

#replace all N/A with 0
function_all.2<-function_all.1%>%
  mutate_at(c(6:11), ~replace(., is.na(.), 0))
View(function_all.2)

#remove sample 77
function_all.3<-function_all.2[-c(831,832),]
View(function_all.3)

#4. Convert functional group sums to proportions for each SAMPLE
#basically each row needs to be summed,and each column needs to be divided by its respective row sum
#DONE IN EXCEL
#in doing this i noticed that 61 SB samples had no germinants and 3 above ground cover quadrats had 0 cover
#verified the no cover above ground quadrats with raw field datasheets - it's correct
#verified the no germ sb data using the "raw" FEER_sb_removalALL_20200121_FORSPECIES file - its correct
#both are off by 1 becuase sample 77 was removed but otherwise everything adds up


#write.table(function_all.3, file="SBAG_FUNCTIONALSUMMARY_USEFORPROPORTIONS_20200121.csv",sep=",",row.names=F)
#write.table(function_all.1, file="SBAG_FUNCTIONALSUMMARY_USEFORQC_20200121.csv",sep=",",row.names=F)

###############################################################################

#5. Subset the data so that we only have the "control" or unburned samples and only the columns we need
#in the end we should have 252 records (252 total samples = 72 unburned samples * 3 deserts + 36 burned samples in the CP)
#for EACH data type (sb vs ag) = 504 total records

View(sb_prop)


#remove unnecessary columns
sb_prop$AF<-NULL
sb_prop$AG<-NULL
sb_prop$PF<-NULL
sb_prop$PG<-NULL
sb_prop$SH<-NULL
sb_prop$TREE<-NULL
sb_prop$SUM<-NULL

View(sb_prop)

#subset again to remove rows of data where the sum of the proportion is 0 (due to 0 AG cover or 0 germs)
sp.prop.1<-subset(sb_prop, SUM_P=="100")
View(sp.prop.1)

#now we only have 473 records so 504-473 = 31 
#this means there were 31 seedbank samples and/or aboveground quadrats that had no cover/no germinants

#"gather" the functional group columns back into "fctngrp" and "ctcvr" for easy figure making

sp.prop.final<-sp.prop.1%>%
  gather("fctngrp", "ctcvr", 6:11)

View(sp.prop.final)
#############################################################################

#subset seed bank data

sb.prop<-subset(sp.prop.final, data_type=="seedbank")
#View(sb.prop)

sbmeans<-summarySE(sb.prop, measurevar="ctcvr", groupvars=c("desert","fctngrp", "burn"))
sbmeans

sbmeans$desert<-factor(sbmeans$desert, levels=c("CP", "GB", "CH", "SO"))
sbmeans$burn<-factor(sbmeans$burn, levels=c("control", "burned"))


#subet aboveground data
ag.prop<-subset(sp.prop.final, data_type=="aboveground")
View(ag.prop)

agmeans<-summarySE(ag.prop, measurevar="ctcvr", groupvars=c("desert","fctngrp", "burn"))
agmeans

agmeans$desert<-factor(agmeans$desert, levels=c("CP", "GB", "CH", "SO"))
agmeans$burn<-factor(agmeans$burn, levels=c("control", "burned"))



########################## FIGURE 2 CODE ################################

#MEGA HORIZONTAL BAR PLOT WITH ABOVE ON LEFT HAND SIDE, BELOW ON RIGHT HAND SIDE WITH
#SUB GROUPINGS OF CH-BURN-I; CH-BURN-S; CH-UNBURN-I; CH-UNBURN-S, ETC. FOR EACH DESERT

#https://stackoverflow.com/questions/18265941/two-horizontal-bar-charts-with-shared-axis-in-ggplot2-similar-to-population-pyr

str(ag.prop)
str(sb.prop)

#create a new field that combines desert, burn status and overstory for aboveground
ag.prop.2<-ag.prop%>%
  unite(new, desert, burn, overstory, sep = "-", remove = FALSE)%>%
  unique(.)

agnewmeans<-summarySE(ag.prop.2, measurevar="ctcvr", groupvars=c("new","fctngrp"))
agnewmeans

#write.csv(agnewmeans, "agnewmeans.csv")
agnewmeans$new<-factor(agnewmeans$new, levels=c("SO-burned-S", "SO-control-S", "SO-burned-I","SO-control-I", 
                                                "CH-burned-S", "CH-control-S", "CH-burned-I","CH-control-I",
                                                "GB-burned-S", "GB-control-S", "GB-burned-I","GB-control-I",
                                                "CP-burned-S", "CP-control-S", "CP-burned-I","CP-control-I"))



ag.new <- ggplot(data = agnewmeans, aes(x = new, y = ctcvr, fill=fctngrp)) +
  xlab(NULL)+
  geom_bar(stat = "identity") + 
  ggtitle("Aboveground") +
  scale_fill_brewer(palette="Set2", labels=c("AF", "AG", "PF", "PG", "SH", "TREE"))+
  theme(axis.title.x = element_blank(), axis.title.y = element_blank(), axis.text = element_text(size = 7),title=element_text(size=9),
        legend.title=element_text(size=9),
        axis.text.y = element_blank(), axis.ticks.y = element_blank(),legend.position="none",
        plot.margin = unit(c(1,0,1,-1), "mm")) +
  coord_flip()+
  scale_y_reverse()
ag.new


#create a new field that combines desert, burn status and overstory for belowground
sb.prop.2<-sb.prop%>%
  unite(new, desert, burn, overstory, sep = "-", remove = FALSE)
str(sb.prop.2)

sbnewmeans<-summarySE(sb.prop.2, measurevar="ctcvr", groupvars=c("new","fctngrp"))
sbnewmeans

#write.csv(sbnewmeans, "sbnewmeans.csv")

sbnewmeans$new<-factor(sbnewmeans$new, levels=c("SO-burned-S", "SO-control-S", "SO-burned-I","SO-control-I", 
                                                "CH-burned-S", "CH-control-S", "CH-burned-I","CH-control-I",
                                                "GB-burned-S", "GB-control-S", "GB-burned-I","GB-control-I",
                                                "CP-burned-S", "CP-control-S", "CP-burned-I","CP-control-I"))


sbnew <- ggplot(data = sbnewmeans, aes(x = new, y = ctcvr, fill=fctngrp)) +
  xlab(NULL)+
  geom_bar(stat = "identity") +
  ggtitle("Seed Bank") +
  labs(fill="Functional Group")+
  scale_fill_brewer(palette="Set2", labels=c("AF", "AG", "PF", "PG", "SH", "TREE"))+
  theme(axis.title.x = element_blank(), axis.title.y = element_blank(), axis.text = element_text(size = 7),title=element_text(size=9),
        legend.title=element_text(size=9),
        axis.text.y = element_blank(), axis.ticks.y = element_blank(),legend.position="right",
        plot.margin = unit(c(1,0,1,-1), "mm")) +
  coord_flip()
sbnew


g.mid<-ggplot(sbnewmeans,aes(x=1,y=new))+geom_text(aes(label=new), size=3)+
  geom_segment(aes(x=0.94,xend=0.95,yend=new))+
  geom_segment(aes(x=1.04,xend=1.055,yend=new))+
  ggtitle("")+
  ylab(NULL)+
  scale_x_continuous(expand=c(0,0),limits=c(0.94,1.055))+
  theme(axis.title=element_blank(),
        panel.grid=element_blank(),
        axis.text.y=element_blank(),
        axis.ticks.y=element_blank(),
        panel.background=element_blank(),
        axis.text.x=element_text(color=NA),
        axis.text = element_text(size = 7),
        legend.title=element_text(size=9),
        axis.ticks.x=element_line(color=NA),
        plot.margin = unit(c(1,-1,1,-1), "mm"))

gg1 <- ggplot_gtable(ggplot_build(ag.new))
gg2 <- ggplot_gtable(ggplot_build(sbnew))
gg.mid <- ggplot_gtable(ggplot_build(g.mid))
grid.arrange(gg1,gg.mid,gg2,ncol=3,widths=c(2/8,1/8,3/8))

tiff("tiff_fig2_sbag.tiff", units="in", width=6, height=6, res=300)

grid.arrange(gg1,gg.mid,gg2,ncol=3,widths=c(2/8,1/8,3/8))
dev.off()
      