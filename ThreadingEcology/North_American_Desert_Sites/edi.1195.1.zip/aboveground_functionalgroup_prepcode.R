#The goal of this script is to reclassify the species found in the aboveground quadrats into
#their respective functional groups so that we can summarize above vs belowground functional group
#proportions by desert and microsite

##preprocessing done before input into R: converting cover values of "t" for "trace" to 0.1 (our smallest value is 0.5 so I just picked something a little smaller)
#also all moss & lichen cover values were removed bc comparing to belowground where we didn't account for crust..

setwd()

chquad<-read.csv("ch_abovegrounddata_quadrat.csv")
chfunction<-read.csv("ch_aboveground_spfctngrp.csv")

cpquad<-read.csv("cp_abovegrounddata_quadrat.csv")
cpfunction<-read.csv("cp_aboveground_spfctngrp.csv")

gbquad<-read.csv("gb_abovegrounddata_quadrat.csv")
gbfunction<-read.csv("gb_aboveground_spfctngrp.csv")

soquad<-read.csv("so_abovegrounddata_quadrat.cs")
sofunction<-read.csv("so_aboveground_spfctngrp.csv")

att<-read.csv("seedbank_attribute_spreadsheet.csv")


library(tidyverse)
library(dplyr)
library(plyr)
library(lubridate)
library(reshape2)
library(tidyr)
library(Rmisc)

##Step 1: "gather" the species id columns, join functional group data, and sum the cover of each functional
#by sample FOR EACH DESERT!

###CHIHUAHUAN

#columns 16:94 are the species columns that we need to collapse into a "ch_spid" and "cover" column
str(chquad)
chquad.1<-gather(chquad,"ch_spid", "cover", 16:94)
#View(chquad.1)
str(chquad.1)
#I got an error "attributes are not identical across measure variables; they will be dropped
#BUT there were 79 species in the CH * 144 samples = 11376 lines of data so I think the data is OK for now

#replace NA's with 0
chquad.2<-chquad.1 %>%
  mutate_at(c(18), ~replace(., is.na(.), 0))
#replace blank cells with 0
chquad.2$cover[chquad.2$cover==""]<- 0
#View(chquad.2)#looks great
str(chquad.2)
str(chfunction)
chquad.2$ch_spid<-as.factor(chquad.2$ch_spid)

#join functional group data
chquad.3<-inner_join(chquad.2, chfunction, by="ch_spid")
#View(chquad.3)
str(chquad.3)
#got an error that joining factors of different levels...but we have the correct # of records

#sum each functional group by unique_ID (bc we don't have sample yet)
chquad.4<-chquad.3%>%
  group_by(unique_ID, fctngrp)%>%
  summarise_at(c("cover"), sum)
View(chquad.4)
#we end up with 720 records which 720/5 functional groups = 144 samples!
#verified total cover counts and total functional group counts for a couple samples to make sure it matches up
chAGsum<-chquad.4 #use chAGsum to combine with other deserts
View(chAGsum)

###COLORADO PLATEAU

#columns 13:59 are the species columns that we need to collapse into a "cp_spid" and "cover" column
str(cpquad)
cpquad.1<-gather(cpquad,"cp_spid", "cover", 13:59)
#View(cpquad.1) #5076 records = 47 species in CP * 108 cp samples = 5076
str(cpquad.1)

#replace NA's with 0
cpquad.2<-cpquad.1 %>%
  mutate_at(c(14), ~replace(., is.na(.), 0))
#replace blank cells with 0
cpquad.2$cover[cpquad.2$cover==""]<- 0
#View(cpquad.2)#looks great 
str(cpquad.2)

#convert spID to a factor to match spID in functional group file
cpquad.2$cp_spid<-as.factor(cpquad.2$cp_spid)
str(cpquad.2)

#join functional group data
str(cpfunction)
View(cpfunction)
cpquad.3<-inner_join(cpquad.2, cpfunction, by="cp_spid")
View(cpquad.3)

#sum each functional group by unique_ID (bc we don't have sample yet)
cpquad.4<-cpquad.3%>%
  group_by(unique_ID, fctngrp)%>%
  summarise_at(c("cover"), sum)
View(cpquad.4)
#we end up with 648 records which 648/108 SAMPLES = 6 functional groups (CP is the only one with TREE so it has an extra)
#verified total cover counts and total functional group counts for a couple samples to make sure it matches up
cpAGsum<-cpquad.4 #use chAGsum to combine with other deserts

###GREAT BASIN

#columns 15:48 are the species columns that we need to collapse into a "cp_spid" and "cover" column
str(gbquad)
gbquad.1<-gather(gbquad,"gb_spid", "cover", 15:48)
View(gbquad.1) #4896 records = 34 species in GB * 144 GB samples = 4896
str(gbquad.1)

#replace NA's with 0
gbquad.2<-gbquad.1 %>%
  mutate_at(c(17), ~replace(., is.na(.), 0))
#replace blank cells with 0
gbquad.2$cover[gbquad.2$cover==""]<- 0
View(gbquad.2)#looks great 

#convert spID to a factor to match spID in functional group file
gbquad.2$gb_spid<-as.factor(gbquad.2$gb_spid)
str(gbquad.2)

#join functional group data
str(gbfunction)
#View(gbfunction)
gbquad.3<-inner_join(gbquad.2, gbfunction, by="gb_spid")
View(gbquad.3)
#error message, joining factors with different levels, but # of records is correct

#sum each functional group by unique_ID (bc we don't have sample # yet)
gbquad.4<-gbquad.3%>%
  group_by(unique_ID, fctngrp)%>%
  summarise_at(c("cover"), sum)
View(gbquad.4)
#we end up with 720 records which 720/144 SAMPLES = 5 functional groups 
#verified total cover counts and total functional group counts for a couple samples to make sure it matches up
gbAGsum<-gbquad.4 #use chAGsum to combine with other deserts

###SONORAN

#columns 16:67 are the species columns that we need to collapse into a "cp_spid" and "cover" column
str(soquad)
soquad.1<-gather(soquad,"so_spid", "cover", 16:67)
#View(soquad.1) #7488 records = 52 species in SO * 144 SO samples = 7488
str(soquad.1)

#replace NA's with 0
soquad.2<-soquad.1 %>%
  mutate_at(c(18), ~replace(., is.na(.), 0))
#replace blank cells with 0
soquad.2$cover[soquad.2$cover==""]<- 0
#View(soquad.2)#looks great 

#convert spID to a factor to match spID in functional group file
soquad.2$so_spid<-as.factor(soquad.2$so_spid)
str(soquad.2)

#join functional group data
str(sofunction)
#View(sofunction)
soquad.3<-inner_join(soquad.2, sofunction, by="so_spid")
#View(soquad.3)
str(soquad.3)

#sum each functional group by unique_ID (bc we don't have sample # yet)
soquad.4<-soquad.3%>%
  group_by(unique_ID, fctngrp)%>%
  summarise_at(c("cover"), sum)
View(soquad.4)
#we end up with 720 records which 720/144 SAMPLES = 5 functional groups 
#verified total cover counts and total functional group counts for a couple samples to make sure it matches up
soAGsum<-soquad.4 #use chAGsum to combine with other deserts


##Step 2: combine all deserts into 1 data frame, append the attribute information (so that we can get 
#sample numbers that will allow us to merge the SB data later, that way all above and below ground data
#will be in one dataframe for easier figure-making : ) ##APPEND "DATA_TYPE" BACK OT THIS FILE
View(soAGsum)
str(soAGsum)
View(gbAGsum)
str(gbAGsum)
View(chAGsum)
str(chAGsum)
View(cpAGsum)
str(cpAGsum)

#combine all of the desert data together
aboveground<-rbind(soAGsum,gbAGsum,chAGsum,cpAGsum)
View(aboveground)
#i'm getting an error abount unequal factors but the number of records is correct and the file looks fine

#add back a column that distinguishes the data_type as "AG" for aboveground
aboveground$data_type <- c("aboveground")

View(aboveground)

##Step 3: append the attribute data by "unique_ID"
str(att)
str(aboveground)
aboveground$unique_ID<-as.factor(aboveground$unique_ID)

aboveground.final<-full_join(aboveground, att, by="unique_ID")
View(aboveground.final)

##Step 4: export the data for later use in making figures
write.table(aboveground.final, file="aboveground_fctnlgrpsummary_20200121.csv",sep=",",row.names=F)

