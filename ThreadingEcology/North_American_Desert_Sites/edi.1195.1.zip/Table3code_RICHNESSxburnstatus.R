#The purpose of this code is to compare species richness by burn status for all deserts

#helpful links:
#https://www.webpages.uidaho.edu/range357/notes/Diversity.pdf
#https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4224527/


setwd()
speciesdataset<-read.csv("seedbank_ghousecountdata_species.csv")
attribute<-read.csv("seedbank_attribute_spreadsheet.csv")
specieslist<-read.csv("seedbank_greenhouse_specieslist.csv")

library(tidyverse)
#install.packages("dplyr")
library(dplyr)
library(plyr)
library(lubridate)
library(ggplot2)
library(vegan)
library(reshape2)
library(tidyr)
library(Rmisc)


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~DATA PREP~~~~~~~~~~~~~~~~~~~~~~~~~~
#create a unique ID so that we can average by plotXmicrosite level
#and select only the fields that I need
enviro.1<-attribute%>%
  unite(unique, fullplot_name, overstory, sep = "-", remove = FALSE)%>%
  dplyr::select(sample, unique, desert, TSF2, overstory, burn, plot_num)

enviro.2<-enviro.1%>%
  dplyr::select(desert, burn, plot_num, TSF2)%>%
  distinct(.)

View(enviro.2)

#append usda codes, habit, duration, etc. to the removals table
removal1<-full_join(speciesdataset, specieslist, by="sp_id")
#View(removal1)

#select only the sample, species ID and count columns from the original removals spreadsheet
#group all species ID's by sample and sum the "count" column for each sample x species
removal2<-removal1%>%
  dplyr::select(sample, count, USDA)
#View(removal2)
#verify the # total number of germinants is correct, 5416, CHECK!
sum(removal2$count)

removal3<-removal2%>%
  group_by(sample, USDA)%>%
  summarise_at(vars(count), funs(sum))
#View(removal3)

#verify the # total number of germinants is correct
sum(removal3$count) #5416 check!

#calculate seeds/m2
#convert each "count" to seeds/m2
#20,000 cm3/m2 for a 2 cm depth divided by our total sample size - 169.65 cm3 for a 6 cm by 2 cm core
#create the function(below)
seedstom2<-function(x){
  x*117.9
  
}

#create a new column that multiplies the no. seesd per sample or "count" by the function to give seeds/m2
removal3$seedsm2<-seedstom2(removal3$count)
sum(removal3$count) #yep, check!

#convert this data to "wide" sample by species format
removalwide<-dcast(removal3,sample ~ USDA, value.var = "count")
View(removalwide)

#append the "unique column from att.1 to removal3 so we have all 540 samples plus unique ID
removalwide.1<-full_join(removalwide, enviro.1, by="sample")
View(removalwide.1)

#remove unnecessary columns
removalwide.2<-removalwide.1
removalwide.2$sample <- NULL
removalwide.2$desert<-NULL
removalwide.2$TSF2<-NULL
removalwide.2$overstory<-NULL
removalwide.2$unique<-NULL
removalwide.2$burn<-NULL
#remove sample 77
View(removalwide.2)
removalwide.2<-removalwide.2[-c(533),]
View(removalwide.2)

#replace all NAs with 0
str(removalwide.2)
removalwide.3<-removalwide.2 %>%
  mutate_at(c(1:90), ~replace(., is.na(.), 0))
#View(removalwide.3)
str(removalwide.3)

#average counts for each PLOT so we end up with 45 rows
removalwide.4<-removalwide.3%>%
  group_by(plot_num)%>%
  summarise_all("mean")
View(removalwide.4)


#order the PLOT for the diversity matrix and the environmental data so they match
#that way, when we the info back in, it'll match up
removal.final <-removalwide.4[order(removalwide.4$plot_num),]
#View(removalwide.5)

att.final<-enviro.2[order(enviro.2$plot_num),]
#View(enviro.3)

View(removal.final)
View(att.final)

######################### Calculate indices  ########################################

#need to convert all columns from numeric to integers
removal.final %>%
  mutate_if(is.numeric,as.integer) 

#shannon diversity
H<-diversity(removal.final[,-1], "shannon")
H
View(H)

#simpsons diversity
S<-diversity(removal.final[,-1], index="simpson")
S
view(S)


#Richness
R<-specnumber(removal.final[,-1])
R
View(R)

#extract the plot num
plot<-removal.final$plot_num
#View(unique)

#bind the proper sample number with diversity and evenness
removalDIVERSITY<-cbind(plot, att.final,R,H,S)
View(removalDIVERSITY)
removalDIVERSITY$plot<-NULL

#cross check a couple records with raw data to be sure this makes sense
crosscheck<-full_join(removal3, enviro.1, by="sample")
View(crosscheck)
#write.csv(crosscheck, file="diversitytableverification_20200414.csv")
#View(removal3)
#view(enviro.1)
#I checked species richness for a couple plots as a proxy for the rest...
#cool, I trust it!


################################### PAIRWISE FOR RICHNESS ~ DESERT + BURN #####################

##############CH DENSITY BURN/UNBURN
richdataset.ch<-subset(removalDIVERSITY, desert=="CH")
str(richdataset.ch)
View(richdataset.ch)
hist(richdataset.ch$R)
shapiro.test(richdataset.ch$R) #normal
boxplot(R ~ burn, data = richdataset.ch)
bartlett.test(R ~ burn, data = richdataset.ch)#barlet assumes normalty, results say homogeneous
fligner.test(R ~ burn, data = richdataset.ch)#fligner robust against normality, homogeneity, wilcoxon would be OK
#tests say normality and homogeneity OK


#t test with var.eq=T THIS IS THE TEST USED FOR RESULTS!!!!
t.test(R ~ burn, data=richdataset.ch, mu=0, alt="two.sided", var.eq=T) #not diff



chmeans<-summarySE(richdataset.ch, measurevar = "R", groupvars = "burn")
chmeans



##############CP DENSITY BURN/UNBURN
richnessdataset.cp<-subset(removalDIVERSITY, desert=="CP")
str(richnessdataset.cp)
View(richnessdataset.cp)
hist(richnessdataset.cp$R)
shapiro.test(richnessdataset.cp$R) #normal
boxplot(R ~ burn, data = richnessdataset.cp)
bartlett.test(R ~ burn, data = richnessdataset.cp) #homogeneity
fligner.test(R ~ burn, data = richnessdataset.cp) #homogeneity
#tests say normality and homogeneity OK


#data normal, homogeneity OK..can do a t test with var.eq=t THIS IS THE TEST USED FOR RESULTS
t.test(R ~ burn, data=richnessdataset.cp, mu=0, alt="two.sided", var.eq=T)


cpmeans<-summarySE(richnessdataset.cp, measurevar = "R", groupvars = "burn")
cpmeans

###################GB DENSITY BURN/UNBURN
richnessdataset.gb<-subset(removalDIVERSITY, desert=="GB")
str(richnessdataset.gb)
View(richnessdataset.gb)
hist(richnessdataset.gb$R)
shapiro.test(richnessdataset.gb$R) #not normal but p 0.048
boxplot(R ~ burn, data = richnessdataset.gb)
fligner.test(R ~ burn, data = richnessdataset.gb)#homogeneity!!, wilcoxon may be OK...
bartlett.test(R ~ burn, data = richnessdataset.gb)#also homogeneity


t.test(R ~ burn, data=richnessdataset.gb, mu=0, alt="two.sided", var.eq=T)

gbmeans<-summarySE(richnessdataset.gb, measurevar = "R", groupvars = "burn")
gbmeans

####################SO DENSITY BURN/UNBURN
richnessdataset.so<-subset(removalDIVERSITY, desert=="SO")
str(richnessdataset.so)
View(richnessdataset.so)
hist(richnessdataset.so$R)
shapiro.test(richnessdataset.so$R) # normal
boxplot(R ~ burn, data = richnessdataset.so)
bartlett.test(R ~ burn, data = richnessdataset.so) #homogeneous
fligner.test(R ~ burn, data = richnessdataset.so)#homogeneity!!


#t test with var.eq=T THIS IS THE TEST USED FOR RESULTS!!!!
t.test(R ~ burn, data=richnessdataset.so, mu=0, alt="two.sided", var.eq=T)
#not sig.

someans<-summarySE(richnessdataset.so, measurevar = "R", groupvars = "burn")
someans

