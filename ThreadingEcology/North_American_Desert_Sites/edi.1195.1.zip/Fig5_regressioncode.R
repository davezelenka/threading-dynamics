#The goal of this code is to look at the relationship between shrub cover and seed density.

setwd()
densitydataset<-read.csv("seedbank_ghousecountdata_density.csv")
attribute<-read.csv("seedbank_attribute_spreadsheet.csv")
aboveground<-read.csv("aboveground_fctnlgrpsummary.csv")

library(rcompanion)
library(FSA)
library(Rmisc)
library(dplyr)
library(tidyr)
library(ggpubr)
library(ggplot2)
library(gvlma)
library(lmtest)
library(broom)
#install.packages("gridExtra")
library(gridExtra)

####################data prep

str(densitydataset)

#Step 1: sum the counts for each sample, join attribute data, calculate seeds/m2 and merge with necessary attributes
densitydataset.1<-densitydataset%>%
  group_by(sample)%>%
  summarise_at(vars(count), funs(sum))

#verify the count
sum(densitydataset.1$count) #yes, this is 5674 which is correct

#join attribute table
densitydataset.2<-full_join(densitydataset.1, attribute, by="sample")
#view(densitydataset.2)

#select only the attributes we need; replace NA's (for the samples without germs)
str(densitydataset.2)
densitydataset.3<-densitydataset.2%>%
  select(sample, count, burn, desert, block_num, overstory)%>%
  mutate_at(c(2), ~replace(., is.na(.), 0))
#triple check the count
sum(densitydataset.3$count) #yes, this is 5674 which is correct

#calculate seeds/m2
#convert each "count" to seeds/m2
#20,000 cm3/m2 for a 2 cm depth divided by our total sample size - 169.65 cm3 for a 6 cm by 2 cm core
#create the function(below)
seedstom2<-function(x){
  x*117.9
  
}

#create a new column that multiplies the no. seesd per sample or "count" by the function to give seeds/m2
densitydataset.3$seedsm2<-seedstom2(densitydataset.3$count)
View(densitydataset.3)


#Step 2: "spread" aboveground functional groups and extract shrub cover and merge it with density data
View(aboveground)
str(aboveground)

aboveground.1<-aboveground%>%
  spread(fctngrp, cover)
str(aboveground.1)

aboveground.2<-aboveground.1%>%
  mutate_at(c(18:23), ~replace(., is.na(.), 0))

aboveground.3<-aboveground.2%>%
  mutate(SHTR = rowSums(select(.,SH:TREE))) %>%
  select(sample, SHTR)

View(aboveground.3)



densitydataset.final<-full_join(densitydataset.3, aboveground.3, by="sample")
View(densitydataset.final)

#remove sample 77
densitydataset.final<-densitydataset.final[-c(535),]
str(densitydataset.final)

cbPalette <- c("#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")


#after meeting with pradip, decided that kendalls is best becuase spearmans gives us an error related to ties
#and kendalls is more robust
#his suggestion was to add both s/i samples to the same plot and label the R and P values for kendall's coeff for each

################################## each desert w/ shrub and inter combined ########################
#https://rpkgs.datanovia.com/ggpubr/reference/ggscatter.html
#color by overstory
#add r/p values for each regression

#####Chihuahuan
regression.CH<-subset(densitydataset.final, desert=="CH")

hist(regression.CH$seedsm2)
hist(regression.CH$SHTR)
ggqqplot(regression.CH$seedsm2)
ggqqplot(regression.CH$SHTR)

#plot using spearmans
chall<-ggscatter(regression.CH, x="SHTR", y="seedsm2", 
                 add="reg.line", 
                 color="overstory",
                 shape="overstory",
                 xlab="Shrub cover (%)", 
                 ylab="Density (seeds/m2)", 
                 palette="jco",
                 title="Chihuahuan" )+
  stat_cor(method="kendall", aes(color=overstory, label = paste(..rr.label.., ..p.label.., sep = "~`,`~")), label.x=3,size=3)+
  scale_shape_manual(values=c(1, 1), guide="none")+
  labs(color="Microsite:", guide="none")+
  scale_color_manual(values=cbPalette,labels=c("Interspace", "Shrub"))+
  guides(shape=FALSE)+
  theme(legend.position = "bottom", 
        axis.text = element_text(size = 7), 
        axis.title = element_text(size = 8),
        title=element_text(size=9),
        legend.title=element_text(size=9))
chall



#kendall cor test
chall.ken <- cor.test(regression.CH$seedsm2, regression.CH$SHTR,  method="kendall")
chall.ken

##SIGNIFICANT BUT COR COEF IS LOW 0.22-0.3


#####Colorado Plateau
regression.CP<-subset(densitydataset.final, desert=="CP")
#plot using spearmans


cpall<-ggscatter(regression.CP, x="SHTR", y="seedsm2", 
                 add="reg.line", 
                 color="overstory", 
                 shape="overstory",
                 xlab="Shrub cover (%)", 
                 ylab="Density (seeds/m2)", 
                 palette="jco",
                 title="Colorado Plateau",
                 xlim=c(0,130))+
  stat_cor(method="kendall", aes(color=overstory, label = paste(..rr.label.., ..p.label.., sep = "~`,`~")), label.x=3,size=3)+
  scale_shape_manual(values=c(1, 1), guide="none")+
  labs(color="Microsite:", guide="none")+
  scale_color_manual(values=cbPalette,labels=c("Interspace", "Shrub"))+
  guides(shape=FALSE)+
  theme(legend.position = "bottom", 
        axis.text = element_text(size = 7), 
        axis.title = element_text(size = 8),
        title=element_text(size=9),
        legend.title=element_text(size=9))
cpall

?scale_shape_manual()


#kendall cor test
cpall.ken <- cor.test(regression.CP$seedsm2, regression.CP$SHTR,  method="kendall")
cpall.ken

#NOT SIG

#####GREAT BASIN
regression.GB<-subset(densitydataset.final, desert=="GB")
#plot using spearmans
gball<-ggscatter(regression.GB, x="SHTR", y="seedsm2", 
                 add="reg.line", 
                 color="overstory",
                 shape="overstory",
                 xlab="Shrub cover (%)", 
                 ylab="Density (seeds/m2)", 
                 palette="jco",
                 title="Great Basin" )+
  stat_cor(method="kendall", aes(color=overstory, label = paste(..rr.label.., ..p.label.., sep = "~`,`~")), label.x=3,size=3)+
  scale_shape_manual(values=c(1, 1), guide="none")+
  labs(color="Microsite:", guide="none")+
  scale_color_manual(values=cbPalette,labels=c("Interspace", "Shrub"))+
  guides(shape=FALSE)+
  theme(legend.position = "bottom", 
        axis.text = element_text(size = 7), 
        axis.title = element_text(size = 8),
        title=element_text(size=9),
        legend.title=element_text(size=9))
gball




#kendall cor test
gball.ken <- cor.test(regression.GB$seedsm2, regression.GB$SHTR,  method="kendall")
gball.ken

#NOT SIG

#####Sonoran
regression.SO<-subset(densitydataset.final, desert=="SO")
#View(regression.SO)
#plot using spearmans
soall<-ggscatter(regression.SO, x="SHTR", y="seedsm2", 
                 add="reg.line", 
                 shape="overstory",
                 color="overstory",
                 xlab="Shrub cover (%)", 
                 ylab="Density (seeds/m2)", 
                 palette="jco",
                 title="Sonoran" )+
  stat_cor(method="kendall", aes(color=overstory, label = paste(..rr.label.., ..p.label.., sep = "~`,`~")), label.x=3,size=3)+
  scale_shape_manual(values=c(1, 1), guide="none")+
  labs(color="Microsite:", guide="none")+
  scale_color_manual(values=cbPalette,labels=c("Interspace", "Shrub"))+
  guides(shape=FALSE)+
  theme(legend.position = "bottom", 
        axis.text = element_text(size = 7), 
        axis.title = element_text(size = 8),
        title=element_text(size=9),
        legend.title=element_text(size=9))
soall



#kendall cor test
soall.ken <- cor.test(regression.SO$seedsm2, regression.SO$SHTR,  method="kendall")
soall.ken


#----------------------------------------
grid.arrange(cpall, gball, chall, soall, nrow=2)


tiff("tfig7regression_raw.tiff", units="in", width=6, height=6, res=300)

# insert ggplot code
fig7<-ggarrange(cpall, gball, chall, soall, nrow=2,ncol=2, legend="bottom", common.legend=TRUE)
fig7
dev.off()


annotate_figure(fig7,
                left = text_grob("Density (seeds/m2)", size = 8, rot=90),
                bottom = text_grob("Shrub cover (%)", size=8)) #this mostly works but it puts the x axis label underneath the legend...

