#the goal of this script is to compare seed densities by burn status for each desert

setwd()
densitydataset<-read.csv("seedbank_ghousecountdata_density.csv")
attribute<-read.csv("seedbank_attribute_spreadsheet.csv")
View(densitydataset)

library(rcompanion)
#install.packages("FSA")
library(FSA)
library(Rmisc)
#install.packages("dplyr")
library(dplyr)
#install.packages("ggpubr")
library(ggpubr)
#install.packages("pscl")
library(pscl)
library(lmtest)
library(multcompView)
library(multcomp)
#install.packages("emmeans")
library(emmeans)
library(car)
#install.packages("forcats")
library(forcats)
#install.packages("vegan")
library(vegan)
library(tidyr)


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~DATA PREP~~~~~~~~~~~~~~~~~~~~~~~~~~
#create a unique ID so that we can average by plotXmicrosite level
#and select only the fields that I need
enviro.1<-attribute%>%
  unite(unique, fullplot_name, overstory, sep = "-", remove = FALSE)%>%
  dplyr::select(sample, unique, desert, TSF2, overstory, burn, plot_num)

enviro.2<-enviro.1%>%
  dplyr::select(desert, burn, TSF2, plot_num)%>%
  distinct(.)

View(enviro.2)

removal<-densitydataset%>%
  group_by(sample)%>%
  summarise_at(vars(count), funs(sum))

#verify the # total number of germinants is correct
sum(removal$count) #5674 check!

#calculate seeds/m2
#convert each "count" to seeds/m2
#20,000 cm3/m2 for a 2 cm depth divided by our total sample size - 169.65 cm3 for a 6 cm by 2 cm core
#create the function(below)
seedstom2<-function(x){
  x*117.9
  
}

#create a new column that multiplies the no. seesd per sample or "count" by the function to give seeds/m2
removal$seedsm2<-seedstom2(removal$count)
sum(removal$count) #yep, check!


#append the "unique column from att.1 to removal3 so we have all 540 samples plus unique ID
removal2<-full_join(removal, enviro.1, by="sample")
View(removal2)

#remove unnecessary columns
removal3<-removal2
removal3$sample <- NULL
removal3$desert<-NULL
removal3$TSF2<-NULL
removal3$overstory<-NULL
removal3$burn<-NULL
#remove sample 77
View(removal3)
removal3<-removal3[-c(535),]
View(removal3)

#replace all NAs with 0
str(removal3)
removal4<-removal3 %>%
  mutate_at(c(1:2), ~replace(., is.na(.), 0))
View(removal4)
str(removal4)

#average counts for each PLOT so we end up with 45 values
removal5<-removal4%>%
  group_by(plot_num)%>%
  summarise_at(vars(count, seedsm2), funs(mean))
View(removal5)

#reappend desert and burn info
final<-full_join(removal5, enviro.2, by="plot_num")
View(final)

################################### PAIRWISE FOR DENSITY ~ DESERT + BURN #####################

##############CH DENSITY BURN/UNBURN
densitydataset.ch<-subset(final, desert=="CH")
str(densitydataset.ch)
View(densitydataset.ch)
hist(densitydataset.ch$seedsm2)
shapiro.test(densitydataset.ch$seedsm2) #normal
boxplot(seedsm2 ~ burn, data = densitydataset.ch)
bartlett.test(seedsm2 ~ burn, data = densitydataset.ch)#heteroscedastic but p=0.0455
fligner.test(seedsm2 ~ burn, data = densitydataset.ch)#homogeneous p=0.07
#normal, heteroscedastic..welch's is most appropriate

#Welch's - data normal, homogeneity not OK..can do a t test with var.eq=F
t.test(seedsm2 ~ burn, data=densitydataset.ch, mu=0, alt="two.sided", var.eq=F) #not diff


wilcox.test(seedsm2 ~ burn, data=densitydataset.ch) #not different


chmeans<-summarySE(densitydataset.ch, measurevar = "seedsm2", groupvars = "burn")
chmeans


##############CP DENSITY BURN/UNBURN
densitydataset.cp<-subset(final, desert=="CP")
str(densitydataset.cp)
View(densitydataset.cp)
hist(densitydataset.cp$seedsm2)
shapiro.test(densitydataset.cp$seedsm2) #normal (barely)
boxplot(seedsm2 ~ burn, data = densitydataset.cp)
bartlett.test(seedsm2 ~ burn, data = densitydataset.cp) #homogeneity even though it doesnt look like it..??
fligner.test(seedsm2~burn, data=densitydataset.cp) #try fligner in case data aren't really normal- heterogeneous (p=0.03)
#t.test maybe welch's would work

#welch's test
t.test(seedsm2 ~ burn, data=densitydataset.cp, mu=0, alt="two.sided", var.eq=F) #not diff

wilcox.test(seedsm2 ~ burn, data=densitydataset.cp, exact=F)#not different


cpmeans<-summarySE(densitydataset.cp, measurevar = "seedsm2", groupvars = "burn")
cpmeans

###################GB DENSITY BURN/UNBURN
densitydataset.gb<-subset(final, desert=="GB")
str(densitydataset.gb)
View(densitydataset.gb)
hist(densitydataset.gb$seedsm2)
shapiro.test(densitydataset.gb$seedsm2) #not normal
boxplot(seedsm2 ~ burn, data = densitydataset.gb)
fligner.test(seedsm2 ~ burn, data = densitydataset.gb)#homogeneity!! even though boxplots don't look like it!
#wilcoxon test most appropriate for not normal, but homogeneous

wilcox.test(seedsm2 ~ burn, data=densitydataset.gb, exact=F) # different!!


gbmeans<-summarySE(densitydataset.gb, measurevar = "seedsm2", groupvars = "burn")
gbmeans

#################### SO DENSITY BURN/UNBURN
densitydataset.so<-subset(final, desert=="SO")
str(densitydataset.so)
View(densitydataset.so)
hist(densitydataset.so$seedsm2)
shapiro.test(densitydataset.so$seedsm2) # normal
boxplot(seedsm2 ~ burn, data = densitydataset.so)
bartlett.test(seedsm2 ~ burn, data = densitydataset.so)#homogeneous


wilcox.test(seedsm2 ~ burn, data=densitydataset.so) # NO different


someans<-summarySE(densitydataset.so, measurevar = "seedsm2", groupvars = "burn")
someans
