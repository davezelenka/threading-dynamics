#The goal of this script is to reclassify the species found in the seedbank samples into
#their respective functional groups so that we can summarize above vs belowground functional group
#proportions by desert and microsite

#special note: using the FEER_sb_removalALL_20200121_FORSPECIES file which does NOT include "DEAD" germs or germs that we were unable to identify
#to verify data, total "count" for this file should be 5416

setwd()

sb<-read.csv("seedbank_ghousecountdata_species.csv")
sbspecies<-read.csv("seedbank_greenhouse_specieslist.csv")
att<-read.csv("seedbank_attribute_spreadsheet.csv")


library(tidyverse)
library(dplyr)
library(plyr)
library(lubridate)
library(reshape2)
library(tidyr)
library(Rmisc)

##Step 1: append the functional group data to the seed bank "species ID's"

sb.1<-full_join(sb, sbspecies, by="sp_id")
View(sb.1)

#Step 2: sum seed counts by functional group for each SAMPLE

sb.2<-sb.1%>%
  group_by(sample, fctngrp)%>%
  summarise_at(c("count"), sum)
View(sb.2)

#verify that the total count is corret
sum(sb.2$count) #5416 perf!!

##Step 3: append the attribute data by "sample"

sb.3<-full_join(sb.2, att, by="sample")
View(sb.3)

#Step 4: replace NA's with 0 (for the samples that had no germinants emerge - 
#after removing contaminants, deads, and unknowns this is up to 62 samples)
sb.final<-sb.3%>%
  mutate_at(c(3), ~replace(., is.na(.), 0))
View(sb.final)

#there are still NA values in the functional group column for the samples that had no germs 
#which may cause problems later but we'll see, we need to make sure those "0" samples stay in 
#and are included in the averages

#Step 5: add a "data_type" column "seedbank"
sb.final$data_type <- c("seedbank")
View(sb.final)
#final check of count sums
sum(sb.final$count) #5416 perf!!

##Step ??: export the data for later use in making figures
write.table(sb.final, file="seedbank_fctnlgrpsummary_20200121.csv",sep=",",row.names=F)

