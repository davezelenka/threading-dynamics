#the goal of this dataset is to test for any greenhouse block effect 
#&
#compare seed densities across deserts for control samples only

setwd()
densitydataset<-read.csv("seedbank_ghousecountdata_density.csv")
attribute<-read.csv("seedbank_attribute_spreadsheet.csv")

library(rcompanion)
library(FSA)
library(Rmisc)
#install.packages("dplyr")
library(dplyr)
library(ggpubr)
#install.packages("pscl")
library(pscl)
library(lmtest)
library(multcompView)
library(multcomp)
#install.packages("emmeans")
library(emmeans)

##################################### DATA PREP FOR COMBO #############################

str(densitydataset)

#Step 1: sum the counts for each sample
densitydataset.1<-densitydataset%>%
  group_by(sample)%>%
  summarise_at(c("count"), sum)

#verify the count
sum(densitydataset.1$count) #yes, this is 5674 which is correct

#Step 2: join attribute table
densitydataset.2<-full_join(densitydataset.1, attribute, by="sample")
#View(densitydataset.2)

#Step 3: select only the attributes we need; replace NA's (for the samples without germs)
str(densitydataset.2)
densitydataset.3<-densitydataset.2%>%
  dplyr::select(sample, count, burn, TSF2, overstory, desert, block_num)%>%
  mutate_at(c(2), ~replace(., is.na(.), 0))
#triple check the count
sum(densitydataset.3$count) #yes, this is 5674 which is correct

#step 4: calculate seeds/m2
#convert each "count" to seeds/m2
#20,000 cm3/m2 for a 2 cm depth divided by our total sample size - 169.65 cm3 for a 6 cm by 2 cm core
#create the function(below)
seedstom2<-function(x){
  x*117.9
  
}

#create a new column that multiplies the no. seesd per sample or "count" by the function to give seeds/m2
densitydataset.3$seedsm2<-seedstom2(densitydataset.3$count)
View(densitydataset.3)

#remove sample 77
densitydataset.3<-densitydataset.3[-c(535),]

densitydataset.all<-densitydataset.3 #saving this as a new object becuase this is what we'll use 
#for combo 2: full density dataset - all plots

View(densitydataset.all)

############################ some data exploration on full density dataset WITH RESPECT TO BLOCK ###################

#- normality
hist(densitydataset.all$seedsm2)
shapiro.test(densitydataset.all$seedsm2) # data not normal
ggqqplot(densitydataset.all$seedsm2)

#try log transform
densitydataset.all$logsm2<-log(densitydataset.all$seedsm2)
View(densitydataset.all)
hist(log(densitydataset.all$seedsm2))
shapiro.test(densitydataset.all$logsm2) #doesn't work becuase the log of 0 spits out "-inf"
ggqqplot(log(densitydataset.all$seedsm2))

#try sqrt transform
densitydataset.all$sqrtsm2<-sqrt(densitydataset.all$seedsm2)
hist(log(densitydataset.all$sqrtsm2))
shapiro.test(densitydataset.all$sqrtsm2) #doesn't work becuase the log of 0 spits out "-inf"
ggqqplot(log(densitydataset.all$sqrtsm2))

#neither transformation is great for normality

#-equal variance..in all tests if P is less than 0.05 then REJECT null that variances are equal and assume HETERSCEDASTICITY
boxplot(seedsm2~block_num, data=densitydataset.all)
bartlett.test(seedsm2 ~ block_num, data = densitydataset.all) 
#small p value = unequal variance BUT this test is sensitive to normality and our data is not normal
#try the levene's test as an alternative
library(car)
str(densitydataset.all)
densitydataset.all$block_num<-as.factor(densitydataset.all$block_num)
leveneTest(seedsm2 ~ block_num, data = densitydataset.all) #homogeneity!
fligner.test(seedsm2 ~ block_num, data = densitydataset.all)#homogeneity!

#summary: data not normal but homogeneity exists.
#so, we can do kruskal because it can handle non-normality but can't handle heteroscedasticity which we DON"T have


#kruskal just to see results
kruskal.test(seedsm2~block_num, data=densitydataset.all)
#null hypothesis is that all groups are equal (i.e. all blocks have equal counts)
#p value is 0.9388 so we CANNOT reject our null hypothesis
#thus, all blocks are ~equal and therefore, no block effect



###########COMPARE SEED DENSITIES ACROSS DESERTS FOR CONTROL SAMPLES ONLY######################

hist(log(densitydataset.all$sqrtsm2))
#perform shapiro test for normality
shapiro.test(densitydataset.all$sqrtsm2) #doesn't work becuase the log of 0 spits out "-inf"
#follow up with qq plot
ggqqplot(log(densitydataset.all$sqrtsm2))
#there are many test that can test homogeneity of variances but fligner is especially robust if your data are not normal
fligner.test(seedsm2 ~ block_num, data = densitydataset.all)
#if p value is greater than 0.05, variances are homogeneous

#if data are NOT normal and homogeneity assumptions are met, then kruskal wallis can be done with no fears of assumption violation : )
#null hypothesis is that all groups are equal (i.e. means of all groups are equal) so if p value is GREATER than 0.05
#you cannot reject the null hypothesis

densitydataset.con<-densitydataset.all[grep("con", densitydataset.all$burn), ]
View(densitydataset.con)

kw.combo1<-kruskal.test(seedsm2~desert, data=densitydataset.con)
kw.combo1

#Step D: Dunn Test as post-hoc to determine which groups are diff from one another
#following code/methodology found here: https://rcompanion.org/handbook/F_08.html

dt.combo1<-dunnTest(count~desert, data=densitydataset.con, method="bh")
dt.combo1

PT=dt.combo1$res

combo1letters<-cldList(P.adj~Comparison, data=PT, threshold=0.05)
combo1letters

densitysummarycontrolonly<-summarySE(densitydataset.con, measurevar = "seedsm2", groupvars = "desert")
densitysummarycontrolonly
