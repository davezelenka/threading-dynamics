#the goal of this script is use ordinations/permanovas to understand how the seed bank community
#changes with time since fire, across deserts, and microsites

#THIS SCRIPT SPECIFICALLY WILL ORDINATE COMMUNITIES FOR EACH DESERT SEPARATELY
#AND RUN AN ADONIS WITH DESERTXCOMMUNITY ~ TSF + OVERSTORY
#https://link.springer.com/content/pdf/10.1186/s40168-019-0659-9.pdf


#INDICATOR SP ANAYLSIS FOLLOWED THIS CODE:
#https://jkzorz.github.io/2019/07/02/Indicator-species-analysis.html

setwd()
speciesdataset<-read.csv("seedbank_ghousecountdata_species.csv")
attribute<-read.csv("seedbank_attribute_spreadsheet.csv")
specieslist<-read.csv("seedbank_greenhouse_specieslist.csv")
View(attribute)

library(tidyverse)
#install.packages("dplyr")
library(dplyr)
library(lubridate)
library(ggplot2)
library(vegan)
library(reshape2)
#install.packages("ggrepel")
library(ggrepel)
library(gridExtra)
#install.packages("ggthemes")
library(ggthemes)
library(RColorBrewer)
#install.packages("indicspecies")
library(indicspecies)


##################################### DATA PREP ###############################################
#create a "uniqueid" column in the attribute table that consists of the plot name and microsite
View(attribute)
att.1<-attribute%>%
  unite(unique, fullplot_name, overstory, sep = "-", remove = FALSE)%>%
  dplyr::select(sample, unique)
View(att.1)
#use the one above to merge with removal data to add UNIQUE ID field

att.2<-attribute%>%
  unite(unique, fullplot_name, overstory, sep = "-", remove = FALSE)

att.3<-att.2%>%
  dplyr::select(unique, desert, TSF2, burn, overstory, fire_name, plot_num)%>%
  distinct(.)

att.3$DST<-paste(att.3$desert,att.3$fire_name, att.3$TSF2, sep="-")
att.3$DT<-paste(att.3$desert,att.3$TSF2, sep="-")
att.3$DO<-paste(att.3$desert,att.3$overstory,sep="-")
att.3$TO<-paste(att.3$TSF2,att.3$overstory, sep="-")

View(att.3)
#use att.3 as final "environmental data"

###########removal data prep

#append usda codes to the removals data
species.1<-full_join(speciesdataset, specieslist, by="sp_id")
sum(species.1$count)#check 5416 is right!
#View(species.1)

#select only the sample, species ID and count columns from the original removals spreadsheet
#group all species ID's by sample and sum the "count" column for each sample x species
species.2<-species.1%>%
  dplyr::select(sample, count, USDA)
#verify the # total number of germinants is correct
sum(species.2$count) #yep, check!
#View(species.2)
str(species.2)
#sum the count for each USDA code for each sample
species.3<-species.2%>%
  group_by(sample, USDA)%>%
  summarise_at(c("count"), sum)
sum(species.3$count) #yep, check!
#View(species.3)

#calculate seeds/m2
#convert each "count" to seeds/m2
#20,000 cm3/m2 for a 2 cm depth divided by our total sample size - 169.65 cm3 for a 6 cm by 2 cm core
#create the function(below)
seedstom2<-function(x){
  x*117.9
  
}

#create a new column that multiplies the no. seesd per sample or "count" by the function to give seeds/m2
species.3$seedsm2<-seedstom2(species.3$count)
str(species.3)
sum(species.3$count) #yep, check!

#remove "count" column
species.4<-species.3
species.4$count<-NULL

#convert this data to "wide" sample by species format
str(species.4)
species.5<-spread(species.4, USDA, seedsm2)
View(species.5)


#append the "unique column from att.1 to removal3 so we have all 540 samples plus unique ID
species.6<-full_join(species.5, att.1, by="sample")

#replace all NAs with 0
str(species.6)
species.7<-species.6 %>%
  mutate_at(c(2:91), ~replace(., is.na(.), 0))
View(species.7)

#remove "count" column
species.8<-species.7
species.8$count<-NULL

#remove sample 77
View(species.8)
str(species.8)
species.8<-species.8[-c(533),]

#average the counts for each UNIQUE ID
species.9<-species.8%>%
  group_by(unique)%>%
  summarise_all("mean")

View(species.9)

#remove the sample column 
species.9$sample <- NULL

####################### FINAL DATASETS FOR REVIEW #########################

#final species data
species.final<-species.9
str(species.final)
View(species.final)

#final attribute data
att.final<-att.3
str(att.final)
View(att.final)

########################### separate each desert #######################

#subset species matrices
###when subsetting...i'm not removing species that don't exist for a specific desert
#for example..there are 90 unique taxa TOTAL across all 4 deserts, when I subset the CH, i'm leaving
#all 90 in there...even though maybe only 30/90 are actually present in the CH samples...

species.chjcb<-species.final[grep("CH-JCB", species.final$unique), ]
View(species.chjcb)
species.chknt<-species.final[grep("CH-KNT", species.final$unique), ]
View(species.chknt)
species.cpshort<-species.final[grep("MV-00|MV-CON", species.final$unique), ]
View(species.cpshort)
species.cplong<-species.final[grep("MV-89|MV-CON", species.final$unique), ]
View(species.cplong)
species.gbrad<-species.final[grep("GB-RAD", species.final$unique), ]
str(species.gbrad)
species.gbow<-species.final[grep("GB-OW", species.final$unique), ]
str(species.gbow)
species.sogat<-species.final[grep("SO-GAT", species.final$unique), ]
str(species.sogat)
species.sogst<-species.final[grep("SO-GST", species.final$unique), ]
str(species.sogst)

#subset ATTRIBUTE matrices

att.chjcb<-att.final[grep("CH-JCB", species.final$unique), ]
View(att.chjcb)
att.chknt<-att.final[grep("CH-KNT", species.final$unique), ]
View(att.chknt)
att.cpshort<-att.final[grep("MV-00|MV-CON", species.final$unique), ]
str(att.cpshort)
att.cplong<-att.final[grep("MV-89|MV-CON", species.final$unique), ]
str(att.cplong)
att.gbrad<-att.final[grep("GB-RAD", species.final$unique), ]
str(att.gbrad)
att.gbow<-att.final[grep("GB-OW", species.final$unique), ]
str(att.gbow)
att.sogat<-att.final[grep("SO-GAT", species.final$unique), ]
str(att.sogat)
att.sogst<-att.final[grep("SO-GST", species.final$unique), ]
str(att.sogst)

##############################PERMANOVAS for table4!####################################

#do burn/unburn diffe?

#burn/unburn for JCB 01 fire
ch.adonis.jcb<-adonis(species.chjcb[, -1] ~ burn * overstory,  data=att.chjcb,  method="bray", permutations=4999)
ch.adonis.jcb

#overstory as strata, RESULTS NOT DIFFERENT
ch.adonis.jcb2<-adonis(species.chjcb[, -1] ~ burn * overstory,  data=att.chjcb, strata=att.chjcb$overstory,  method="bray", permutations=4999)
ch.adonis.jcb2

#burn + overstory 
ch.adonis.jcb3<-adonis(species.chjcb[, -1] ~ burn, strata=att.chjcb$overstory, data=att.chjcb,  method="bray", permutations=4999)
ch.adonis.jcb3

#burn/unburn for KNT 89 fire
ch.adonis.knt<-adonis(species.chknt[, -1] ~ burn * overstory, data=att.chknt,  method="bray", permutations=4999)
ch.adonis.knt

#overstory as strata, RESULTS NOT DIFFERENT
ch.adonis.knt2<-adonis(species.chknt[, -1] ~ burn * overstory, data=att.chknt, strata=att.chknt$overstory, method="bray", permutations=4999)
ch.adonis.knt2


#####colorado plateau
#burn/unburn for young fire
cp.adonis.short<-adonis(species.cpshort[, -1] ~ burn * overstory, data=att.cpshort,method="bray", permutations=4999)
cp.adonis.short

#overstory as different; RESULTS DIFFERENT/ OVERSTORY SIG.
cp.adonis.short2<-adonis(species.cpshort[, -1] ~ burn * overstory,strata=att.cpshort$overstory, data=att.cpshort,method="bray", permutations=4999)
cp.adonis.short2

#burn/unburn for old fire
cp.adonis.long<-adonis(species.cplong[, -1] ~ burn * overstory, data=att.cplong, method="bray", permutations=4999)
cp.adonis.long

#overstory as different; RESULTS DIFFERENT/ OVERSTORY SIG.
cp.adonis.long2<-adonis(species.cplong[, -1] ~ burn * overstory, strata=att.cplong$overstory, data=att.cplong, method="bray", permutations=4999)
cp.adonis.long2

#####Great basin
#burn/unburn for young OW fire
gb.adonis.ow<-adonis(species.gbow[, -1] ~ burn * overstory, data=att.gbow,method="bray", permutations=4999)
gb.adonis.ow

#overstory as different; RESULTS DIFFERENT/ OVERSTORY SIG.
gb.adonis.ow2<-adonis(species.gbow[, -1] ~ burn * overstory, strata=att.gbow$overstory, data=att.gbow,method="bray", permutations=4999)
gb.adonis.ow2


#burn/unburn for old RAD fire
gb.adonis.rad<-adonis(species.gbrad[, -1] ~ burn * overstory, data=att.gbrad, method="bray", permutations=4999)
gb.adonis.rad

#burn/unburn for old RAD fire
gb.adonis.rad2<-adonis(species.gbrad[, -1] ~ burn * overstory,strata=att.gbrad$overstory, data=att.gbrad, method="bray", permutations=4999)
gb.adonis.rad2


#####Sonoran
#burn/unburn for young GST fire
so.adonis.gst<-adonis(species.sogst[, -1] ~ burn * overstory,  data=att.sogst, method="bray", permutations=4999)
so.adonis.gst

#overstory as strata
so.adonis.gst2<-adonis(species.sogst[, -1] ~ burn * overstory, strata=att.sogst$overstory, data=att.sogst, method="bray", permutations=4999)
so.adonis.gst2


#burn/unburn for old GAT fire
so.adonis.gat<-adonis(species.sogat[, -1] ~ burn * overstory, data=att.sogat, method="bray", permutations=4999)
so.adonis.gat

#overstory as strata
so.adonis.gat2<-adonis(species.sogat[, -1] ~ burn * overstory, strata=att.sogat$overstory, data=att.sogat, method="bray", permutations=4999)
so.adonis.gat2


############ do shrub/interspace differ when controlling for burn??

#burn/unburn for JCB 01 fire
ch.adonis.jcb3<-adonis(species.chjcb[, -1] ~ overstory, strata=att.chjcb$burn,  data=att.chjcb,  method="bray", permutations=4999)
ch.adonis.jcb3

ch.adonis.jcb4<-adonis(species.chjcb[, -1] ~ overstory,  data=att.chjcb,  method="bray", permutations=4999)
ch.adonis.jcb4

#burn/unburn for KNT 89 fire
ch.adonis.knt2<-adonis(species.chknt[, -1] ~ overstory, strata=att.chknt$burn,  data=att.chknt,  method="bray", permutations=4999)
ch.adonis.knt2


#####colorado plateau
#burn/unburn for young fire
cp.adonis.short2<-adonis(species.cpshort[, -1] ~ overstory, strata=att.cpshort$burn, data=att.cpshort,method="bray", permutations=4999)
cp.adonis.short2

#burn/unburn for old fire
cp.adonis.long2<-adonis(species.cplong[, -1] ~ overstory, strata=att.cplong$burn,  data=att.cplong, method="bray", permutations=4999)
cp.adonis.long2


#####Great basin
#burn/unburn for young OW fire
gb.adonis.ow2<-adonis(species.gbow[, -1] ~ overstory, strata=att.gbow$burn, data=att.gbow,method="bray", permutations=4999)
gb.adonis.ow2

#burn/unburn for old RAD fire
gb.adonis.rad2<-adonis(species.gbrad[, -1] ~ overstory, strata=att.gbrad$burn, data=att.gbrad, method="bray", permutations=4999)
gb.adonis.rad2


#####Sonoran
#burn/unburn for young GST fire
so.adonis.gst2<-adonis(species.sogst[, -1] ~ overstory, strata=att.sogst$burn, data=att.sogst,method="bray", permutations=4999)
so.adonis.gst2

#burn/unburn for old GAT fire
so.adonis.gat2<-adonis(species.sogat[, -1] ~ overstory, strata=att.sogat$burn, data=att.sogat, method="bray", permutations=4999)
so.adonis.gat2

######################### Chihuahuan ordinations  & indicator species analysis ################################################

#due diligence to determine what the no. of dimensions should/could be
ch<-vegdist(species.ch[, -1], method="bray", binary=FALSE)


### CHIHUAHUAN BETADISPER TO UNDERSTAND GROUP VARIANCES
#beta disper needs the distance matrix "ch" below..
#USING METHOD FROM HERE:
#https://rdrr.io/rforge/vegan/man/permutest.betadisper.html

#TSF2
chtsfbetadisp<-betadisper(ch, att.ch$TSF2, type=c("median", "centroid"), bias.adjust=FALSE)
chtsfbetadisp
permutest(chtsfbetadisp)
anova(chtsfbetadisp)
chtsfperm<-permutest(chtsfbetadisp, pairwise = FALSE, permutations=999)
chtsfperm
(chtsftukey<-TukeyHSD(chtsfbetadisp))
chtsftukey
plot(chtsftukey)
chtsfstat<-permustats(chtsfperm)
densityplot(chtsfstat)
qqmath(chtsfstat)
##all p values are greater .05 so I think that means homogeneity for ch-tsf2 

#overstory
overchbeta<-betadisper(ch, att.ch$overstory, type=c("median", "centroid"), bias.adjust=FALSE)
overchbeta
permutest(overchbeta)
anova(overchbeta)
overchperm<-permutest(overchbeta, pairwise = FALSE, permutations=999)
overchperm
(overchtukey<-TukeyHSD(overchbeta))
overchtukey
plot(overchtukey)
overchstat<-permustats(overchperm)
densityplot(overchstat)
qqmath(overchstat)
##all p values are greater .05 so I think that means homogeneity for ch-overstory 


#burn_unburned
chburnbeta<-betadisper(ch, att.ch$burn, type=c("median", "centroid"), bias.adjust=FALSE)
chburnbeta
permutest(chburnbeta)
anova(chburnbeta)
chburnperm<-permutest(chburnbeta, pairwise = FALSE, permutations=999)
chburnperm
(chburntukey<-TukeyHSD(chburnbeta))
chburntukey
plot(chburntukey)
chburnstat<-permustats(chburnperm)
densityplot(chburnstat)
qqmath(chburnstat)
##all p values are greater .05 so I think that means homogeneity for ch-burn

#TO (time & overstory combined)
chTObeta<-betadisper(ch, att.ch$TO, type=c("median", "centroid"), bias.adjust=FALSE)
chTObeta
permutest(chTObeta)
anova(chTObeta)
chTOperm<-permutest(chTObeta, pairwise = FALSE, permutations=999)
chTOperm
(chTOtukey<-TukeyHSD(chTObeta))
chTOtukey
plot(chTOtukey)
chTOstat<-permustats(chTOperm)
densityplot(chTOstat)
qqmath(chTOstat)
##all p values are greater .05 so I think that means homogeneity for ch-TO

#in conclusion....tsf, overstory and burn/unburn and TO all have homogeneity of variances between groups

#SITE 
chsitebeta<-betadisper(ch, att.ch$fire_name, type=c("median", "centroid"), bias.adjust=FALSE)
chsitebeta
permutest(chsitebeta)
anova(chsitebeta)
#site also has homogeneity

### CHIHUAHUAN ADONIS TO TEST SIGNIFICANCE OF TSF AND OVERSTORY

#burn/unburn for JCB fire
ch.adonis.jcb<-adonis(species.chjcb[, -1] ~ overstory + burn/plot_num, data=att.chjcb, strata=att.chjcb$burn, method="bray", permutations=4999)
ch.adonis.jcb

#burn/unburn for KNT fire
ch.adonis.knt<-adonis(species.chknt[, -1] ~ overstory + burn/plot_num, data=att.chknt, strata=att.chknt$burn, method="bray", permutations=4999)
ch.adonis.knt

View(species.chknt)

#FOLLOW ADONIS UP WITH PLOT OF CENTROIDS FOR EACH GROUP TO SEE IF THAT MAKES SENSE

#plot centroids of TSF
chscrs<-scores(CH.NMDS.DIST, display="sites")
chTSFscrs<-cbind(as.data.frame(chscrs), TSF=att.ch$TSF2)
chTSFcent<-aggregate(cbind(NMDS1, NMDS2)~TSF, data=chTSFscrs, FUN=mean)
CHTSFsegs <- merge(chTSFscrs, setNames(chTSFcent, c('TSF','oNMDS1','oNMDS2')),
              by = 'TSF', sort = FALSE)
chtsfplot<-ggplot(chTSFscrs, aes(x = NMDS1, y = NMDS2, colour = TSF)) +
  geom_segment(data = CHTSFsegs,
               mapping = aes(xend = oNMDS1, yend = oNMDS2)) + # spiders
  geom_point(data = chTSFcent, size = 4) +                         # centroids
  geom_point() +                                              # sample scores
  theme_bw()+
  theme(legend.position="bottom")+
  scale_color_discrete(name="Time-Since-Fire")+
  coord_fixed()
chtsfplot


#plot centroids of overstory
choverscrs<-cbind(as.data.frame(chscrs), M=att.ch$overstory)
chovercent<-aggregate(cbind(NMDS1, NMDS2)~M, data=choverscrs, FUN=mean)
choversegs <- merge(choverscrs, setNames(chovercent, c('M','oNMDS1','oNMDS2')),
                   by = 'M', sort = FALSE)
choverplot<-ggplot(choverscrs, aes(x = NMDS1, y = NMDS2, colour = M)) +
  geom_segment(data = choversegs,
               mapping = aes(xend = oNMDS1, yend = oNMDS2)) + # spiders
  geom_point(data = chovercent, size = 4) +                         # centroids
  geom_point() +                                              # sample scores
  theme_bw()+
  theme(legend.position="bottom")+
  scale_color_discrete(name="Overstory")+
  coord_fixed()
choverplot

#plot centroids of tsf-overstory combined

chcombscrs<-cbind(as.data.frame(chscrs), TO=att.ch$TO)
chcombcent<-aggregate(cbind(NMDS1, NMDS2)~TO, data=chcombscrs, FUN=mean)
chcombsegs <- merge(chcombscrs, setNames(chcombcent, c('TO','oNMDS1','oNMDS2')),
                    by = 'TO', sort = FALSE)
chcombplot<-ggplot(chcombscrs, aes(x = NMDS1, y = NMDS2, colour = TO)) +
  geom_segment(data = chcombsegs,
               mapping = aes(xend = oNMDS1, yend = oNMDS2)) + # spiders
  geom_point(data = chcombcent, size = 4) +                         # centroids
  geom_point() +                                              # sample scores
  theme_bw()+
  theme(legend.position="bottom")+
  scale_color_discrete(name="TSF + Overstory")+
  coord_fixed()
chcombplot


#plot centroids of burn
chburnscrs<-cbind(as.data.frame(chscrs), burn=att.ch$burn)
chburncent<-aggregate(cbind(NMDS1, NMDS2)~burn, data=chburnscrs, FUN=mean)
chburnsegs <- merge(chburnscrs, setNames(chburncent, c('burn','oNMDS1','oNMDS2')),
                    by = 'burn', sort = FALSE)
chburnplot<-ggplot(chburnscrs, aes(x = NMDS1, y = NMDS2, colour = burn)) +
  geom_segment(data = chburnsegs,
               mapping = aes(xend = oNMDS1, yend = oNMDS2)) + # spiders
  geom_point(data = chburncent, size = 4) +                         # centroids
  geom_point() +                                              # sample scores
  theme_bw()+
  theme(legend.position="bottom")+
  scale_color_discrete(name="BURN")+
  coord_fixed()
chburnplot


#plot centroids of SITES
chsitescrs<-cbind(as.data.frame(chscrs), site=att.ch$fire_name)
chsitecent<-aggregate(cbind(NMDS1, NMDS2)~site, data=chsitescrs, FUN=mean)
chsitesegs <- merge(chsitescrs, setNames(chsitecent, c('site','oNMDS1','oNMDS2')),
                    by = 'site', sort = FALSE)
chsiteplot<-ggplot(chsitescrs, aes(x = NMDS1, y = NMDS2, colour = site)) +
  geom_segment(data = chsitesegs,
               mapping = aes(xend = oNMDS1, yend = oNMDS2)) + # spiders
  geom_point(data = chsitecent, size = 4) +                         # centroids
  geom_point() +                                              # sample scores
  theme_bw()+
  theme(legend.position="bottom")+
  scale_color_discrete(name="SITE")+
  coord_fixed()
chsiteplot

########CH indicator species analysis
#https://jkzorz.github.io/2019/07/02/Indicator-species-analysis.html
#using time/overstory as a grouped variable
View(att.ch)
chsp<-species.ch[,-1]
chto<-att.ch$TO
chtoinv<-multipatt(chsp, chto, control = how(nperm=9999))
summary(chtoinv)
summary(chtoinv, alpha=1)
coverage(chsp, chinv)
#a few sig. related to time-overstory combined variables

#using just TSF
chsp<-species.ch[,-1]
chtsf<-att.ch$TSF2
chinvtsf<-multipatt(chsp, chtsf, control = how(nperm=9999))
summary(chinvtsf)
#no species you find signifincatly more often in any TSF group


#using just overstory
chsp<-species.ch[,-1]
chover<-att.ch$overstory
chinvover<-multipatt(chsp, chover,control = how(nperm=9999))
summary(chinvover)
#DEPI IS FOUND SIGNIFICANTLY MORE OFTEN UNDER S THAN I


#using just burn
chsp<-species.ch[,-1]
chburn<-att.ch$burn
chinvburn<-multipatt(chsp, chburn, control = how(nperm=9999))
summary(chinvburn)
#no species you find signifincatly more often in any TSF group

#using just SITE (i.e 15 sites vs 30 yr sites)
chsp<-species.ch[,-1]
chsite<-att.ch$fire_name
chinvsite<-multipatt(chsp, chsite, control = how(nperm=9999))
summary(chinvsite)
#no species you find signifincatly more often in any sote 

######################### Colorado Plateau ordinations  & indicator species analysis################################################

#due diligence to determine what the no. of dimensions should/could be
View(att.cp)
cp<-vegdist(species.cp[, -1], method="bray", binary=FALSE)

NMDS.scree <- function(x) { 
  plot(rep(1, 10), replicate(10, metaMDS(x, autotransform = F, k = 1)$stress), xlim = c(1, 10),ylim = c(0, 0.30), xlab = "# of Dimensions", ylab = "Stress", main = "NMDS stress plot")
  for (i in 1:10) {
    points(rep(i + 1,10),replicate(10, metaMDS(x, autotransform = F, k = i + 1)$stress))
  }
}


NMDS.scree(cp) #scree shows stress at approx 0.11at k=2 dimensions, so k=2 should be OK
warnings()
#each time i run this i get 30 warnings, or 24 warnings....
#warning that 1: In metaMDS(x, autotransform = F, k = i + 1) :
#stress is (nearly) zero: you may have insufficient data


#using distance matrix to do NMDS
CP.NMDS.dist <- metaMDS(cp,k = 2, trymax = 100, trace = FALSE)
CP.NMDS.dist
CP.NMDS.dist$stress #0.1259314 
stressplot(CP.NMDS.dist)


#ordplot using distance  matrix
cpdist<-ordiplot(CP.NMDS.dist, type="points")
ordihull(cpdist, att.cp$TO, col=1:13,lwd=3, label=TRUE)
plot(cpspfit, p.max = 0.05, col = "black")

#use ggplot to customize the NMDS plot following this resource
#https://www.rpubs.com/RGrieger/545184

#fit environmental and species variables
cp.envfit<-envfit(CP.NMDS.dist, att.cp, permutations = 999)
#try re-fitting species as vectors and getting stats based on distance NMDS
cpspfit <- envfit(CP.NMDS.dist, species.cp[,-1], perm = 9999, na.rm = TRUE)
scores(cpspfit, "vectors")
plot(cpspfit, p.max = 0.05, col = "black")
cpspfit
#pretty different from the last version; maca does not come out in the indicator sp analysis

#save "coordinates" of the sites and bind environmental data
cp.site.scrs <- as.data.frame(scores(CP.NMDS.dist, display = "sites"))
cp.site.scrs <- cbind(cp.site.scrs, Overstory = att.cp$overstory)
cp.site.scrs <- cbind(cp.site.scrs, TSF = att.cp$TSF2)
head(cp.site.scrs)

cp.nmds.plot<-ggplot(cp.site.scrs, aes(x=NMDS1, y=NMDS2))+
  geom_point(aes(NMDS1, NMDS2, colour=factor(cp.site.scrs$TSF), shape=factor(cp.site.scrs$Overstory)), size=6)+
  coord_fixed()+
  theme_classic()+
  scale_colour_colorblind()+
  theme(panel.background = element_rect(fill = NA, colour = "black", size = 1, linetype = "solid"))+
  labs(colour = "Time Since Fire", shape = "Microsite", title="Colorado Plateau" )+ 
  theme(legend.position = "bottom", legend.text = element_text(size = 15), legend.title = element_text(size = 15), axis.text = element_text(size = 15), plot.title=element_text(size=20)) 

cp.nmds.plot


### Colorado Plateau BETADISPER TO UNDERSTAND GROUP VARIANCES
#beta disper needs the distance matrix "cP" below..
#USING METHOD FROM HERE:
#https://rdrr.io/rforge/vegan/man/permutest.betadisper.html

#TSF2
cptsfbetadisp<-betadisper(cp, att.cp$TSF2, type=c("median", "centroid"), bias.adjust=FALSE)
cptsfbetadisp
permutest(cptsfbetadisp)
anova(cptsfbetadisp)
cptsfperm<-permutest(cptsfbetadisp, pairwise = FALSE, permutations=999)
cptsfperm
(cptsftukey<-TukeyHSD(cptsfbetadisp))
cptsftukey
plot(cptsftukey)
cptsfstat<-permustats(cptsfperm)
densityplot(cptsfstat)
qqmath(cptsfstat)
##p values less than 0.05 for anova and perm tests...post hoc only shows significance between 30f and 15F
#so...at least some heterogeneity between TSF groups is present.

#overstory
overcpbeta<-betadisper(cp, att.cp$overstory, type=c("median", "centroid"), bias.adjust=FALSE)
overcpbeta
permutest(overcpbeta)
anova(overcpbeta)
overcpperm<-permutest(overcpbeta, pairwise = FALSE, permutations=999)
overcpperm
(overcptukey<-TukeyHSD(overcpbeta))
overcptukey
plot(overcptukey)
overcpstat<-permustats(overcpperm)
densityplot(overcpstat)
qqmath(overcpstat)
##all p values are greater .05 so I think that means homogeneity for cp-overstory 


#burn_unburned
cpburnbeta<-betadisper(cp, att.cp$burn, type=c("median", "centroid"), bias.adjust=FALSE)
cpburnbeta
permutest(cpburnbeta)
anova(cpburnbeta)
cpburnperm<-permutest(cpburnbeta, pairwise = FALSE, permutations=999)
cpburnperm
(cpburntukey<-TukeyHSD(cpburnbeta))
cpburntukey
plot(cpburntukey)
cpburnstat<-permustats(cpburnperm)
densityplot(cpburnstat)
qqmath(cpburnstat)
##all p values are greater .05 so I think that means homogeneity for cp-burn

#time/over combined
cpTObeta<-betadisper(cp, att.cp$TO, type=c("median", "centroid"), bias.adjust=FALSE)
cpTObeta
permutest(cpTObeta)
anova(cpTObeta)

#in conclusion....tsf has heterogenetiy while overstory and burn/unburn have homogeneity of variances between groups

### COLORADO PLATEAU ADONIS TO TEST SIGNIFICANCE OF TSF AND OVERSTORY
#after back and forth with scott i think this is the final equation
cp.adonis.1<-adonis(species.cp[, -1] ~ TSF2 + overstory + TSF2/plot_num, data=att.cp, strata=att.cp$TSF2, method="bray", permutations=4999)
cp.adonis.1
hist(cp.adonis.1$f.perms[,1])
hist(cp.adonis.1$f.perms[,2])
hist(cp.adonis.1$f.perms[,3])

#with burn as grouping
cp.adonis.2<-adonis(species.cp[, -1] ~ TSF2 + overstory + TSF2/plot_num, data=att.cp, strata=att.cp$burn, method="bray", permutations=4999)
cp.adonis.2
hist(cp.adonis.1$f.perms[,1])
hist(cp.adonis.1$f.perms[,2])
hist(cp.adonis.1$f.perms[,3])

#with fire-name as strata
cp.adonis.3<-adonis(species.cp[, -1] ~ TSF2 + overstory + TSF2/plot_num, data=att.cp, strata=att.cp$fire_name, method="bray", permutations=999)
cp.adonis.3
hist(cp.adonis.3$f.perms[,1])
hist(cp.adonis.3$f.perms[,2])
hist(cp.adonis.3$f.perms[,3])


#ADONIS CAN'T HANDLE HETEROGENEITY WHICH WE HAVE WITH TSF GROUPS IN THE CP SO
#RESULTS MAY BE TESTING FOR HETEROGENEITY AND NOT ACTUAL SITE DIFFERENCES

#FOLLOW ADONIS UP WITH PLOT OF CENTROIDS FOR EACH GROUP TO SEE IF THAT MAKES SENSE

#plot centroids of TSF
cpscrs<-scores(CP.NMDS.dist, display="sites")
cpTSFscrs<-cbind(as.data.frame(cpscrs), TSF=att.cp$TSF2)
cpTSFcent<-aggregate(cbind(NMDS1, NMDS2)~TSF, data=cpTSFscrs, FUN=mean)
cpTSFsegs <- merge(cpTSFscrs, setNames(cpTSFcent, c('TSF','oNMDS1','oNMDS2')),
                   by = 'TSF', sort = FALSE)
cptsfplot<-ggplot(cpTSFscrs, aes(x = NMDS1, y = NMDS2, colour = TSF)) +
  geom_segment(data = cpTSFsegs,
               mapping = aes(xend = oNMDS1, yend = oNMDS2)) + # spiders
  geom_point(data = cpTSFcent, size = 4) +                         # centroids
  geom_point() +                                              # sample scores
  theme_bw()+
  theme(legend.position="bottom")+
  scale_color_discrete(name="Time-Since-Fire")+
  coord_fixed()
cptsfplot


#plot centroids of overstory
cpoverscrs<-cbind(as.data.frame(cpscrs), M=att.cp$overstory)
cpovercent<-aggregate(cbind(NMDS1, NMDS2)~M, data=cpoverscrs, FUN=mean)
cpoversegs <- merge(cpoverscrs, setNames(cpovercent, c('M','oNMDS1','oNMDS2')),
                    by = 'M', sort = FALSE)
cpoverplot<-ggplot(cpoverscrs, aes(x = NMDS1, y = NMDS2, colour = M)) +
  geom_segment(data = cpoversegs,
               mapping = aes(xend = oNMDS1, yend = oNMDS2)) + # spiders
  geom_point(data = cpovercent, size = 4) +                         # centroids
  geom_point() +                                              # sample scores
  theme_bw()+
  theme(legend.position="bottom")+
  scale_color_discrete(name="Overstory")+
  coord_fixed()
cpoverplot

#plot centroids of tsf-overstory combined

#plot centroids of overstory
cpcombscrs<-cbind(as.data.frame(cpscrs), TO=att.cp$TO)
cpcombcent<-aggregate(cbind(NMDS1, NMDS2)~TO, data=cpcombscrs, FUN=mean)
cpcombsegs <- merge(cpcombscrs, setNames(cpcombcent, c('TO','oNMDS1','oNMDS2')),
                    by = 'TO', sort = FALSE)
cpcombplot<-ggplot(cpcombscrs, aes(x = NMDS1, y = NMDS2, colour = TO)) +
  geom_segment(data = cpcombsegs,
               mapping = aes(xend = oNMDS1, yend = oNMDS2)) + # spiders
  geom_point(data = cpcombcent, size = 4) +                         # centroids
  geom_point() +                                              # sample scores
  theme_bw()+
  theme(legend.position="bottom")+
  scale_color_discrete(name="TSF + Overstory")+
  coord_fixed()
cpcombplot


#plot centroids of burn
cpburnscrs<-cbind(as.data.frame(cpscrs), burn=att.cp$burn)
cpburncent<-aggregate(cbind(NMDS1, NMDS2)~burn, data=cpburnscrs, FUN=mean)
cpburnsegs <- merge(cpburnscrs, setNames(cpburncent, c('burn','oNMDS1','oNMDS2')),
                    by = 'burn', sort = FALSE)
cpburnplot<-ggplot(cpburnscrs, aes(x = NMDS1, y = NMDS2, colour = burn)) +
  geom_segment(data = cpburnsegs,
               mapping = aes(xend = oNMDS1, yend = oNMDS2)) + # spiders
  geom_point(data = cpburncent, size = 4) +                         # centroids
  geom_point() +                                              # sample scores
  theme_bw()+
  theme(legend.position="bottom")+
  scale_color_discrete(name="Burn Status")+
  coord_fixed()
cpburnplot


########CP indicator species analysis
#using time/overstory as a grouped variable
cpsp<-species.cp[,-1]
cpto<-att.cp$TO
cpTOinv<-multipatt(cpsp, cpto, control = how(nperm=9999))
summary(cpTOinv)

#using just TSF
cpsp<-species.cp[,-1]
cptsf<-att.cp$TSF2
cpinvTSF<-multipatt(cpsp, cptsf, control = how(nperm=9999))
summary(cpinvTSF)
#no species you find signifincatly more often in any TSF group


#using just overstory
cpsp<-species.cp[,-1]
cpover<-att.cp$overstory
cpinvover<-multipatt(cpsp, cpover,  control = how(nperm=9999))
summary(cpinvover)
#no species you find sig. more often under shrub vs inter

#using just burn
cpsp<-species.cp[,-1]
cpburn<-att.cp$burn
cpinvburn<-multipatt(cpsp, cpburn, control = how(nperm=9999))
summary(cpinvburn)

View(att.cp)

################################ Great Basin ordinations & indicator species analysis #######################################

#due diligence to determine what the no. of dimensions should/could be
gb<-vegdist(species.gb[, -1], method="bray", binary=FALSE)

NMDS.scree <- function(x) { 
  plot(rep(1, 10), replicate(10, metaMDS(x, autotransform = F, k = 1)$stress), xlim = c(1, 10),ylim = c(0, 0.30), xlab = "# of Dimensions", ylab = "Stress", main = "NMDS stress plot")
  for (i in 1:10) {
    points(rep(i + 1,10),replicate(10, metaMDS(x, autotransform = F, k = i + 1)$stress))
  }
}


NMDS.scree(gb) #scree shows stress at approx 0.1 at k=2 dimensions, so k=2 should be OK


#using distance matrix
GB.NMDS.dist <- metaMDS(gb,k = 2, trymax = 100, trace = FALSE)
GB.NMDS.dist
GB.NMDS.dist$stress #0.14577 
stressplot(GB.NMDS.dist)


#distance  matrix
gbdist<-ordiplot(GB.NMDS.dist, type="points")
ordihull(gbdist, att.gb$TO, col=1:13,lwd=3, label=TRUE)
plot(gbspfit, p.max = 0.05, col = "black")


#use ggplot to customize the NMDS plot following this resource
#https://www.rpubs.com/RGrieger/545184

#fit environmental and species variables
gb.envfit<-envfit(GB.NMDS.dist, att.gb, permutations = 999)

#try re-fitting species as vectors and getting stats based on distance NMDS
gbspfit <- envfit(GB.NMDS.dist, species.gb[,-1], perm = 9999, na.rm = TRUE)
scores(gbspfit, "vectors")
plot(gbspfit, p.max = 0.05, col = "black")
gbspfit
#very similar to my previous versions

#save "coordinates" of the sites and bind environmental data
gb.site.scrs <- as.data.frame(scores(GB.NMDS.dist, display = "sites"))
gb.site.scrs <- cbind(gb.site.scrs, Overstory = att.gb$overstory)
gb.site.scrs <- cbind(gb.site.scrs, TSF = att.gb$TSF2)
head(gb.site.scrs)

gb.nmds.plot<-ggplot(gb.site.scrs, aes(x=NMDS1, y=NMDS2))+
  geom_point(aes(NMDS1, NMDS2, colour=factor(gb.site.scrs$TSF), shape=factor(gb.site.scrs$Overstory)), size=6)+
  coord_fixed()+
  theme_classic()+
  scale_colour_colorblind()+
  theme(panel.background = element_rect(fill = NA, colour = "black", size = 1, linetype = "solid"))+
  labs(colour = "Time Since Fire", shape = "Microsite", title="Great Basin" )+ 
  theme(legend.position = "bottom", legend.text = element_text(size = 15), legend.title = element_text(size = 15), axis.text = element_text(size = 15), plot.title=element_text(size=20)) 

gb.nmds.plot



### Great Basin BETADISPER TO UNDERSTAND GROUP VARIANCES
#beta disper needs the distance matrix "gb" below..
#USING METHOD FROM HERE:
#https://rdrr.io/rforge/vegan/man/permutest.betadisper.html

#TSF2
gbtsfbetadisp<-betadisper(gb, att.gb$TSF2, type=c("median", "centroid"), bias.adjust=FALSE)
gbtsfbetadisp
permutest(gbtsfbetadisp)
anova(gbtsfbetadisp)
gbtsfperm<-permutest(gbtsfbetadisp, pairwise = FALSE, permutations=999)
gbtsfperm
(gbtsftukey<-TukeyHSD(gbtsfbetadisp))
gbtsftukey
plot(gbtsftukey)
gbtsfstat<-permustats(gbtsfperm)
densityplot(gbtsfstat)
qqmath(gbtsfstat)
##all p values are greater .05 so I think that means homogeneity for gb-tsf

#overstory
overgbbeta<-betadisper(gb, att.gb$overstory, type=c("median", "centroid"), bias.adjust=FALSE)
overgbbeta
permutest(overgbbeta)
anova(overgbbeta)
overgbperm<-permutest(overgbbeta, pairwise = FALSE, permutations=999)
overgbperm
(overgbtukey<-TukeyHSD(overgbbeta))
overgbtukey
plot(overgbtukey)
overgbstat<-permustats(overgbperm)
densityplot(overgbstat)
qqmath(overgbstat)
##all p values are greater .05 so I think that means homogeneity for gb-overstory 


#burn_unburned
gbburnbeta<-betadisper(gb, att.gb$burn, type=c("median", "centroid"), bias.adjust=FALSE)
gbburnbeta
permutest(overgbbeta)
anova(gbburnbeta)
gbburnperm<-permutest(gbburnbeta, pairwise = FALSE, permutations=999)
gbburnperm
(gbburntukey<-TukeyHSD(gbburnbeta))
gbburntukey
plot(gbburntukey)
gbburnstat<-permustats(gbburnperm)
densityplot(gbburnstat)
qqmath(gbburnstat)
##all p values are greater .05 so I think that means homogeneity for gb-burn

#time-overstory groups
gbTObeta<-betadisper(gb, att.gb$TO, type=c("median", "centroid"), bias.adjust=FALSE)
gbTObeta
permutest(gbTObeta)
anova(gbTObeta)
gbTOperm<-permutest(gbTObeta, pairwise = FALSE, permutations=999)
gbTOperm
(gbTOtukey<-TukeyHSD(gbTObeta))
gbTOtukey
plot(gbTOtukey)
gbTOstat<-permustats(gbTOperm)
densityplot(gbTOstat)
qqmath(gbTOstat)

#in conclusion....tsf, overstory, time+overstory, and burn/unburn all have homogeneous variances for the GB


### Great basin ADONIS TO TEST SIGNIFICANCE OF TSF AND OVERSTORY
#https://rdrr.io/rforge/vegan/man/adonis.html
#pradip: if main effect IS significant then no need to do interactions

#after back and forth with scott i think this is the final equation
#nothing is sig
gb.adonis.1<-adonis(species.gb[, -1] ~ TSF2 + overstory + TSF2/plot_num, data=att.gb, strata=att.gb$TSF2, method="bray", permutations=4999)
gb.adonis.1
hist(gb.adonis.1$f.perms[,1])
hist(gb.adonis.1$f.perms[,2])
hist(gb.adonis.1$f.perms[,3])

#with burn status as the strata
#just burn is sig.
gb.adonis.2<-adonis(species.gb[, -1] ~ TSF2 + overstory + TSF2/plot_num, data=att.gb, strata=att.gb$burn, method="bray", permutations=4999)
gb.adonis.2
hist(gb.adonis.2$f.perms[,1])
hist(gb.adonis.2$f.perms[,2])
hist(gb.adonis.2$f.perms[,3])

#with fire-name as strata
gb.adonis.3<-adonis(species.gb[, -1] ~ TSF2 + overstory + TSF2/plot_num, data=att.gb, strata=att.gb$fire_name, method="bray", permutations=999)
gb.adonis.3
hist(gb.adonis.3$f.perms[,1])
hist(gb.adonis.3$f.perms[,2])
hist(gb.adonis.3$f.perms[,3])

#FOLLOW ADONIS UP WITH PLOT OF CENTROIDS FOR EACH GROUP TO SEE IF THAT MAKES SENSE

#plot centroids of TSF
gbscrs<-scores(GB.NMDS.dist, display="sites")
gbTSFscrs<-cbind(as.data.frame(gbscrs), TSF=att.gb$TSF2)
gbTSFcent<-aggregate(cbind(NMDS1, NMDS2)~TSF, data=gbTSFscrs, FUN=mean)
gbTSFsegs <- merge(gbTSFscrs, setNames(gbTSFcent, c('TSF','oNMDS1','oNMDS2')),
                   by = 'TSF', sort = FALSE)
gbtsfplot<-ggplot(gbTSFscrs, aes(x = NMDS1, y = NMDS2, colour = TSF)) +
  geom_segment(data = gbTSFsegs,
               mapping = aes(xend = oNMDS1, yend = oNMDS2)) + # spiders
  geom_point(data = gbTSFcent, size = 4) +                         # centroids
  geom_point() +                                              # sample scores
  theme_bw()+
  theme(legend.position="bottom")+
  scale_color_discrete(name="Time-Since-Fire")+
  coord_fixed()
gbtsfplot
#i don't get how this is NOT sig....

#plot centroids of overstory
gboverscrs<-cbind(as.data.frame(gbscrs), M=att.gb$overstory)
gbovercent<-aggregate(cbind(NMDS1, NMDS2)~M, data=gboverscrs, FUN=mean)
gboversegs <- merge(gboverscrs, setNames(gbovercent, c('M','oNMDS1','oNMDS2')),
                     by = 'M', sort = FALSE)
gboverplot<-ggplot(gboverscrs, aes(x = NMDS1, y = NMDS2, colour = M)) +
  geom_segment(data = gboversegs,
               mapping = aes(xend = oNMDS1, yend = oNMDS2)) + # spiders
  geom_point(data = gbovercent, size = 4) +                         # centroids
  geom_point() +                                              # sample scores
  theme_bw()+
  theme(legend.position="bottom")+
  scale_color_discrete(name="Overstory")+
  coord_fixed()
gboverplot
#maybe makes sense that this is not sig..

#plot centroids of tsf-overstory combined
gbcombscrs<-cbind(as.data.frame(gbscrs), TO=att.gb$TO)
gbcombcent<-aggregate(cbind(NMDS1, NMDS2)~TO, data=gbcombscrs, FUN=mean)
gbcombsegs <- merge(gbcombscrs, setNames(gbcombcent, c('TO','oNMDS1','oNMDS2')),
                    by = 'TO', sort = FALSE)
gbcombplot<-ggplot(gbcombscrs, aes(x = NMDS1, y = NMDS2, colour = TO)) +
  geom_segment(data = gbcombsegs,
               mapping = aes(xend = oNMDS1, yend = oNMDS2)) + # spiders
  geom_point(data = gbcombcent, size = 4) +                         # centroids
  geom_point() +                                              # sample scores
  theme_bw()+
  theme(legend.position="bottom")+
  scale_color_discrete(name="TSF + overstory")+
  coord_fixed()
gbcombplot


#plot centroids of burn
gbburnscrs<-cbind(as.data.frame(gbscrs), burn=att.gb$burn)
gbburncent<-aggregate(cbind(NMDS1, NMDS2)~burn, data=gbburnscrs, FUN=mean)
gbburnsegs <- merge(gbburnscrs, setNames(gbburncent, c('burn','oNMDS1','oNMDS2')),
                    by = 'burn', sort = FALSE)
gbburnplot<-ggplot(gbburnscrs, aes(x = NMDS1, y = NMDS2, colour = burn)) +
  geom_segment(data = gbburnsegs,
               mapping = aes(xend = oNMDS1, yend = oNMDS2)) + # spiders
  geom_point(data = gbburncent, size = 4) +                         # centroids
  geom_point() +                                              # sample scores
  theme_bw()+
  theme(legend.position="bottom")+
  scale_color_discrete(name="Burn status")+
  coord_fixed()
gbburnplot
#yeah burn and unburn are def different

#plot centroids of sites
gbsitescrs<-cbind(as.data.frame(gbscrs), site=att.gb$fire_name)
gbsitecent<-aggregate(cbind(NMDS1, NMDS2)~site, data=gbsitescrs, FUN=mean)
gbsitesegs <- merge(gbsitescrs, setNames(gbsitecent, c('site','oNMDS1','oNMDS2')),
                    by = 'site', sort = FALSE)
gbsiteplot<-ggplot(gbsitescrs, aes(x = NMDS1, y = NMDS2, colour = site)) +
  geom_segment(data = gbsitesegs,
               mapping = aes(xend = oNMDS1, yend = oNMDS2)) + # spiders
  geom_point(data = gbsitecent, size = 4) +                         # centroids
  geom_point() +                                              # sample scores
  theme_bw()+
  theme(legend.position="bottom")+
  scale_color_discrete(name="SITE")+
  coord_fixed()
gbsiteplot
#sites also look very different

#######GB indicator species analysis
#using time/overstory as a grouped variable
gbsp<-species.gb[,-1]
gbto<-att.gb$TO
gbTOinv<-multipatt(gbsp, gbto, control = how(nperm=9999))
summary(gbTOinv)
#12 species

#using just TSF
gbsp<-species.gb[,-1]
gbtsf<-att.gb$TSF2
gbinvTSF<-multipatt(gbsp, gbtsf, control = how(nperm=9999))
summary(gbinvTSF)
#no species you find sig. more often in any TSF group

#using just overstory
#View(species.gb)
gbsp<-species.gb[,-1]
gbover<-att.gb$overstory
gbinvover<-multipatt(gbsp, gbover, control = how(nperm=9999))
summary(gbinvover)
#no species you find sig. more often under shrub vs inter

#using just burn
gbsp<-species.gb[,-1]
gbburn<-att.gb$burn
gbinvburn<-multipatt(gbsp, gbburn,func="r.g", control = how(nperm=9999))
summary(gbinvburn)

#using site
gbsp<-species.gb[,-1]
gbsite<-att.gb$fire_name
gbsiteburn<-multipatt(gbsp, gbsite,func="r.g", control = how(nperm=9999))
summary(gbsiteburn)


############################# Sonoran ordinations & indicator species analysis ###############################################
View(species.so)
View(att.so)

#due diligence to determine what the no. of dimensions should/could be
so<-vegdist(species.so[, -1], method="bray", binary=FALSE)

NMDS.scree <- function(x) { 
  plot(rep(1, 10), replicate(10, metaMDS(x, autotransform = F, k = 1)$stress), xlim = c(1, 10),ylim = c(0, 0.30), xlab = "# of Dimensions", ylab = "Stress", main = "NMDS stress plot")
  for (i in 1:10) {
    points(rep(i + 1,10),replicate(10, metaMDS(x, autotransform = F, k = i + 1)$stress))
  }
}


NMDS.scree(so) #scree shows stress at approx 0.125 at k=2 dimensions, so k=2 should be OK


#usign distance matrix
SO.NMDS.dist <- metaMDS(so,k = 2, trymax = 100, trace = FALSE)
SO.NMDS.dist
SO.NMDS.dist$stress #0.1297742 
stressplot(SO.NMDS.dist)


#distance matrix
sodist<-ordiplot(SO.NMDS.dist, type="points")
ordihull(sodist, att.so$TO, col=1:13,lwd=3, label=TRUE)
plot(sospfit, p.max = 0.05, col = "black")


#use ggplot to customize the NMDS plot following this resource
#https://www.rpubs.com/RGrieger/545184

#fit environmental and species variables
#this will "test the significance of the variables using permutational tests" <- from the Vegan handbook
so.envfit<-envfit(SO.NMDS.dist, att.so, permutations = 999)
#try re-fitting species as vectors and getting stats based on distance NMDS
sospfit <- envfit(SO.NMDS.dist, species.so[,-1], perm = 9999, na.rm = TRUE)
warnings() #std dev is 0 bc not all of the 90 sp occur it the sonoran
scores(sospfit, "vectors")
sospfit
#pretty different from the last version

#save "coordinates" of the sites and bind environmental data
so.site.scrs <- as.data.frame(scores(SO.NMDS.dist, display = "sites"))
so.site.scrs <- cbind(so.site.scrs, Overstory = att.so$overstory)
so.site.scrs <- cbind(so.site.scrs, TSF = att.so$TSF2)
head(so.site.scrs)


so.nmds.plot<-ggplot(so.site.scrs, aes(x=NMDS1, y=NMDS2))+
  geom_point(aes(NMDS1, NMDS2, colour=factor(so.site.scrs$TSF), shape=factor(so.site.scrs$Overstory)), size=6)+
  coord_fixed()+
  theme_classic()+
  scale_colour_colorblind()+
  theme(panel.background = element_rect(fill = NA, colour = "black", size = 1, linetype = "solid"))+
  labs(colour = "Time Since Fire", shape = "Microsite", title="Sonoran" )+ 
  theme(legend.position = "bottom", legend.text = element_text(size = 15), legend.title = element_text(size = 15), axis.text = element_text(size = 15), plot.title=element_text(size=20)) 

so.nmds.plot


### Sonoran BETADISPER TO UNDERSTAND GROUP VARIANCES
#beta disper needs the distance matrix "so" below..
#USING METHOD FROM HERE:
#https://rdrr.io/rforge/vegan/man/permutest.betadisper.html

#TSF2
sotsfbetadisp<-betadisper(so, att.so$TSF2, type=c("median", "centroid"), bias.adjust=FALSE)
sotsfbetadisp
anova(sotsfbetadisp)
permutest(sotsfbetadisp)
sotsfperm<-permutest(sotsfbetadisp, pairwise = FALSE, permutations=999)
sotsfperm
(sotsftukey<-TukeyHSD(sotsfbetadisp))
sotsftukey
plot(sotsftukey)
sotsfstat<-permustats(sotsfperm)
densityplot(sotsfstat)
qqmath(sotsfstat)
##all p values are greater .05 so I think that means homogeneity for so-tsf

#overstory
oversobeta<-betadisper(so, att.so$overstory, type=c("median", "centroid"), bias.adjust=FALSE)
oversobeta
anova(oversobeta)
permutest(oversobeta)
oversoperm<-permutest(oversobeta, pairwise = FALSE, permutations=999)
oversoperm
(oversotukey<-TukeyHSD(oversobeta))
oversotukey
plot(oversotukey)
oversostat<-permustats(oversoperm)
densityplot(oversostat)
qqmath(oversostat)
##all p values are greater .05 so I think that means homogeneity for so-overstory 


#burn_unburned
soburnbeta<-betadisper(so, att.so$burn, type=c("median", "centroid"), bias.adjust=FALSE)
soburnbeta
anova(soburnbeta)
permutest(soburnbeta)
soburnperm<-permutest(soburnbeta, pairwise = FALSE, permutations=999)
soburnperm
(soburntukey<-TukeyHSD(soburnbeta))
soburntukey
plot(soburntukey)
soburnstat<-permustats(soburnperm)
densityplot(soburnstat)
qqmath(soburnstat)
##all p values are greater .05 so I think that means homogeneity for so-burn

#time/overstore COMBINED "TO"
soTObeta<-betadisper(so, att.so$TO, type=c("median", "centroid"), bias.adjust=FALSE)
soTObeta
anova(soTObeta)
permutest(soTObeta)
soTOperm<-permutest(soTObeta, pairwise = FALSE, permutations=999)
soTOperm
(soTOtukey<-TukeyHSD(soTObeta))
soTOtukey
plot(soTOtukey)
soTOstat<-permustats(soTOperm)
densityplot(soTOstat)
qqmath(soTOstat)
##all p values are greater .05 so I think that means homogeneity for so-TO combo



### Sonoran ADONIS TO TEST SIGNIFICANCE OF TSF AND OVERSTORY

#with TSF at strata
so.adonis.1<-adonis(species.so[, -1] ~ TSF2 + overstory + TSF2/plot_num, data=att.so, strata=att.so$TSF2, method="bray", permutations=999)
so.adonis.1
hist(so.adonis.1$f.perms[,1])
hist(so.adonis.1$f.perms[,2])
hist(so.adonis.1$f.perms[,3])

#with burn as strata
so.adonis.2<-adonis(species.so[, -1] ~ TSF2 + overstory + TSF2/plot_num, data=att.so, strata=att.so$burn, method="bray", permutations=999)
so.adonis.2
hist(so.adonis.2$f.perms[,1])
hist(so.adonis.2$f.perms[,2])
hist(so.adonis.2$f.perms[,3])

#with fire-name as strata
so.adonis.3<-adonis(species.so[, -1] ~ TSF2 + overstory + TSF2/plot_num, data=att.so, strata=att.so$fire_name, method="bray", permutations=999)
so.adonis.3
hist(so.adonis.3$f.perms[,1])
hist(so.adonis.3$f.perms[,2])
hist(so.adonis.3$f.perms[,3])

#follow adonis up with centroid plots for each grouping 

#plot centroids of TSF
soscrs<-scores(SO.NMDS.dist, display="sites")
soTSFscrs<-cbind(as.data.frame(soscrs), TSF=att.so$TSF2)
soTSFcent<-aggregate(cbind(NMDS1, NMDS2)~TSF, data=soTSFscrs, FUN=mean)
soTSFsegs <- merge(soTSFscrs, setNames(soTSFcent, c('TSF','oNMDS1','oNMDS2')),
                   by = 'TSF', sort = FALSE)
sotsfplot<-ggplot(soTSFscrs, aes(x = NMDS1, y = NMDS2, colour = TSF)) +
  geom_segment(data = soTSFsegs,
               mapping = aes(xend = oNMDS1, yend = oNMDS2)) + # spiders
  geom_point(data = soTSFcent, size = 4) +                         # centroids
  geom_point() +                                              # sample scores
  theme_bw()+
  theme(legend.position="bottom")+
  scale_color_discrete(name="Time-Since-Fire")+
  coord_fixed()
sotsfplot

#plot centroids of overstory
sooverscrs<-cbind(as.data.frame(soscrs), M=att.so$overstory)
soovercent<-aggregate(cbind(NMDS1, NMDS2)~M, data=sooverscrs, FUN=mean)
sooversegs <- merge(sooverscrs, setNames(soovercent, c('M','oNMDS1','oNMDS2')),
                    by = 'M', sort = FALSE)
sooverplot<-ggplot(sooverscrs, aes(x = NMDS1, y = NMDS2, colour = M)) +
  geom_segment(data = sooversegs,
               mapping = aes(xend = oNMDS1, yend = oNMDS2)) + # spiders
  geom_point(data = soovercent, size = 4) +                         # centroids
  geom_point() +                                              # sample scores
  theme_bw()+
  theme(legend.position="bottom")+
  scale_color_discrete(name="Overstory")+
  coord_fixed()
sooverplot

#plot centroids of tsf-overstory combined
socombscrs<-cbind(as.data.frame(soscrs), TO=att.so$TO)
socombcent<-aggregate(cbind(NMDS1, NMDS2)~TO, data=socombscrs, FUN=mean)
socombsegs <- merge(socombscrs, setNames(socombcent, c('TO','oNMDS1','oNMDS2')),
                    by = 'TO', sort = FALSE)
socombplot<-ggplot(socombscrs, aes(x = NMDS1, y = NMDS2, colour = TO)) +
  geom_segment(data = socombsegs,
               mapping = aes(xend = oNMDS1, yend = oNMDS2)) + # spiders
  geom_point(data = socombcent, size = 4) +                         # centroids
  geom_point() +                                              # sample scores
  theme_bw()+
  theme(legend.position="bottom")+
  scale_color_discrete(name="TSF + Overstory")+
  coord_fixed()
socombplot


#plot centroids of burn
soburnscrs<-cbind(as.data.frame(soscrs), burn=att.so$burn)
soburncent<-aggregate(cbind(NMDS1, NMDS2)~burn, data=soburnscrs, FUN=mean)
soburnsegs <- merge(soburnscrs, setNames(soburncent, c('burn','oNMDS1','oNMDS2')),
                    by = 'burn', sort = FALSE)
soburnplot<-ggplot(soburnscrs, aes(x = NMDS1, y = NMDS2, colour = burn)) +
  geom_segment(data = soburnsegs,
               mapping = aes(xend = oNMDS1, yend = oNMDS2)) + # spiders
  geom_point(data = soburncent, size = 4) +                         # centroids
  geom_point() +                                              # sample scores
  theme_bw()+
  theme(legend.position="bottom")+
  scale_color_discrete(name="burn status")+
  coord_fixed()
soburnplot


#plot centroids of sites
sositescrs<-cbind(as.data.frame(soscrs), site=att.so$fire_name)
sositecent<-aggregate(cbind(NMDS1, NMDS2)~site, data=sositescrs, FUN=mean)
sositesegs <- merge(sositescrs, setNames(sositecent, c('site','oNMDS1','oNMDS2')),
                    by = 'site', sort = FALSE)
sositeplot<-ggplot(sositescrs, aes(x = NMDS1, y = NMDS2, colour = site)) +
  geom_segment(data = sositesegs,
               mapping = aes(xend = oNMDS1, yend = oNMDS2)) + # spiders
  geom_point(data = sositecent, size = 4) +                         # centroids
  geom_point() +                                              # sample scores
  theme_bw()+
  theme(legend.position="bottom")+
  scale_color_discrete(name="Site")+
  coord_fixed()
sositeplot
#sites also look very different



#######so indicator species analysis
#using time/overstory as a grouped variable
sosp<-species.so[,-1]
soto<-att.so$TO
sotoinv<-multipatt(sosp, soto, control = how(nperm=9999))
summary(sotoinv)
#8 species

#using just TSF
sosp<-species.so[,-1]
sotsf<-att.so$TSF2
soinvTSF<-multipatt(sosp, sotsf,control = how(nperm=9999))
summary(soinvTSF)
#NO SPECIES WERE  FOUND SIGNIFICANTLY MORE OFTEN IN A PARTICULAR TSF GROUP

#using just overstory
sosp<-species.so[,-1]
soover<-att.so$overstory
soinvover<-multipatt(sosp, soover,control = how(nperm=9999))
summary(soinvover)
#5 SPECIES WERE FOUND SIGNIFICANTLY MORE OFTEN IN SHRUB MICROSITES

#using just burn
sosp<-species.so[,-1]
soburn<-att.so$burn
soinvburn<-multipatt(sosp, soburn, control = how(nperm=9999))
summary(soinvburn)


#using SITE
sosp<-species.so[,-1]
sosite<-att.so$fire_name
soinvsite<-multipatt(sosp, sosite, control = how(nperm=9999))
summary(soinvsite)


######################### major ordination conclusions

#https://chrischizinski.github.io/rstats/vegan-ggplot2/
#will help in figuring out how to color/shape code the sites
#https://stackoverflow.com/questions/56986618/how-to-plot-only-most-abundant-species-in-nmds
#https://www.rpubs.com/RGrieger/545184
#https://www.researchgate.net/post/How_do_I_proceed_after_a_significant_PERMANOVA_test
#https://www.researchgate.net/topic/PERMANOVA
#https://www.researchgate.net/post/R_Script_for_adonis_with_more_levels_of_nestedness
#https://ichthyology.usm.edu/courses/multivariate/feb_7.pdf this website has a good explanation of using plot as strata
#in all of our deserts, using plot as an interaction between time and overstory (i.e. community ~ TSF * plot + overstory * plot) 
#results in LESS unexplained variability than if we were to use community ~ TSF + oversotry with strata=plot
#additionally, the histograms of our f values are much more normal when we use that interaction than when we use strata=plot
#however, they say "if your question is to determine whether or not groups differ while controlling for (plot in our case), 
#you can control the permutations with strata = X


############produce figure 4 of all desert ordinations in one figure

cp.site.scrs.2<-cp.site.scrs%>%
  unite(cpuni, TSF, Overstory,sep = "-", remove = FALSE)

cp.nmds.plot2<-ggplot(cp.site.scrs.2, aes(x=NMDS1, y=NMDS2))+
  geom_point(aes(NMDS1, NMDS2,shape=factor(cpuni)), size=3)+
  coord_fixed()+
  theme_classic()+
  xlim(-0.6, 0.6)+
  ylim(-0.6, 0.6)+
  scale_shape_manual(values = c(1, 19, 0, 15, 2, 17, 5, 23), labels = c("ShortTSF(I)", "ShortTSF(S)", "LongTSF(I)", "LongTSF(S)", "Control(I)", "Control(S)")) +
  guides(colour=guide_legend(nrow=2)) +
  theme(panel.background = element_rect(fill = NA, 
                                        colour = "black",
                                        size = 1, linetype = "solid"),
        legend.position = "none", plot.margin = unit(c(0.1,0,0, 0), "null"),
        legend.text = element_text(size = 7), 
        legend.title = element_text(size = 7),
        axis.title = element_text(size=7),
        axis.text = element_text(size = 6), plot.title=element_text(size=9))+
  labs(colour = "Microsite", shape = "Time-Since-Fire", title="Colorado Plateau")

#cp.nmds.plot2

gb.site.scrs.2<-gb.site.scrs%>%
  unite(gbuni, TSF, Overstory,sep = "-", remove = FALSE)

gb.nmds.plot2<-ggplot(gb.site.scrs.2, aes(x=NMDS1, y=NMDS2))+
  geom_point(aes(NMDS1, NMDS2,shape=factor(gbuni)), size=3)+
  coord_fixed()+
  theme_classic()+
  xlim(-0.6, 0.6)+
  ylim(-0.6, 0.6)+
  guides(colour=guide_legend(nrow=2))+
  scale_shape_manual(values = c(1, 19, 0, 15, 2, 17, 5, 18), labels = c("ShortTSF-Con(I)", "ShortTSF-Con(S)", "ShortTSF-Fire(I)", "ShortTSF-Fire(S)", "LongTSF-Con(I)", "LongTSF-Con(S)", "LongTSF-Fire(I)", "LongTSF-Fire(S)")) +
  theme(panel.background = element_rect(fill = NA, 
                                        colour = "black",
                                        size = 1, linetype = "solid"),
        legend.position = "none",  plot.margin = unit(c(0.1,0,0, 0), "null"),
        legend.text = element_text(size = 7), 
        legend.title = element_text(size = 7),
        axis.title = element_text(size=7),
        axis.text = element_text(size = 6), plot.title=element_text(size=9))+
  labs(colour = "Microsite", shape = "Time-Since-Fire", title="Great Basin")

gb.nmds.plot2

ch.site.scrs.2<-ch.site.scrs%>%
  unite(chuni, TSF, Overstory,sep = "-", remove = FALSE)

ch.nmds.plot2<-ggplot(ch.site.scrs.2, aes(x=NMDS1, y=NMDS2))+
  geom_point(aes(NMDS1, NMDS2, shape=factor(chuni)), size=3)+
  coord_fixed()+
  theme_classic()+
  xlim(-0.6, 0.6)+
  ylim(-0.6, 0.6)+
  guides(colour=guide_legend(nrow=2)) +
  scale_shape_manual(values = c(1, 19, 0, 15, 2, 17, 5, 18), labels = c("ShortTSF-Con(I)", "ShortTSF-Con(S)", "ShortTSF-Fire(I)", "ShortTSF-Fire(S)", "LongTSF-Con(I)", "LongTSF-Con(S)", "LongTSF-Fire(I)", "LongTSF-Fire(S)")) +
  theme(panel.background = element_rect(fill = NA, 
                                        colour = "black",
                                        size = 1, linetype = "solid"),
        legend.position = "none",  plot.margin = unit(c(0.1,0,0, 0), "null"),
        legend.text = element_text(size = 7), 
        legend.title = element_text(size = 7),
        axis.title = element_text(size=7),
        axis.text = element_text(size = 6), plot.title=element_text(size=9))+
  labs(colour = "Microsite", shape = "Time-Since-Fire", title="Chihuahuan")

#ch.nmds.plot2

so.site.scrs.2<-so.site.scrs%>%
  unite(souni, TSF, Overstory,sep = "-", remove = FALSE)

so.nmds.plot2<-ggplot(so.site.scrs.2, aes(x=NMDS1, y=NMDS2))+
  geom_point(aes(NMDS1, NMDS2, shape=factor(souni)), size=3)+
  coord_fixed()+
  theme_classic()+
  xlim(-0.6, 0.6)+
  ylim(-0.6, 0.6)+
  guides(colour=guide_legend(nrow=2)) +
  scale_shape_manual(values = c(1, 19, 0, 15, 2, 17, 5, 18), labels = c("ShortTSF-Con(I)", "ShortTSF-Con(S)", "ShortTSF-Fire(I)", "ShortTSF-Fire(S)", "LongTSF-Con(I)", "LongTSF-Con(S)", "LongTSF-Fire(I)", "LongTSF-Fire(S)")) +
  theme(panel.background = element_rect(fill = NA, 
                                        colour = "black",
                                        size = 1, linetype = "solid"),
        legend.position = "bottom",  plot.margin = unit(c(0.1,0,0, 0), "null"),
        legend.text = element_text(size = 7), 
        legend.title = element_text(size = 7),
        axis.title = element_text(size=7),
        axis.text = element_text(size = 6), plot.title=element_text(size=9))+
  labs(colour = "Microsite", shape = "Time-Since-Fire", title="Sonoran")

#so.nmds.plot2

library(gridExtra)
library(grid)
library(ggplot2)
library(lattice)
library(ggpubr)

tiff("tif_ord_fig4_20220108.tiff", units="in", width=5.5, height=5.5, res=300)
ggarrange(gb.nmds.plot2,cp.nmds.plot2, ch.nmds.plot2, so.nmds.plot2,
          nrow=2,ncol=2, 
          legend="bottom", common.legend=TRUE,widths=c(1/2,1/2,1/2,1/2))
dev.off()

