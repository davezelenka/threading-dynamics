#the goal of this script is to compare species richness by microsite for each desert

#helpful links:
#https://www.webpages.uidaho.edu/range357/notes/Diversity.pdf
#https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4224527/


setwd()
speciesdataset<-read.csv("FEER_sb_removalALL_20200226_FORSPECIES.csv")
attribute<-read.csv("seedbank_attribute_spreadsheet.csv")
specieslist<-read.csv("seedbank_greenhouse_specieslist.csv")

library(tidyverse)
#install.packages("dplyr")
library(dplyr)
library(plyr)
library(lubridate)
library(ggplot2)
library(vegan)
library(reshape2)
library(tidyr)
library(Rmisc)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~DATA PREP~~~~~~~~~~~~~~~~~~~~~~~~~~
#create a unique ID so that we can average by plotXmicrosite level
#and select only the fields that I need
enviro.1<-attribute%>%
  unite(unique, fullplot_name, overstory, sep = "-", remove = FALSE)%>%
  dplyr::select(sample, unique, desert, TSF2, overstory, burn, plot_num)

enviro.2<-enviro.1%>%
  dplyr::select(desert, burn, plot_num, TSF2, overstory, unique)%>%
  distinct(.)

View(enviro.2)

#append usda codes, habit, duration, etc. to the removals table
removal1<-full_join(speciesdataset, specieslist, by="sp_id")
#View(removal1)

#select only the sample, species ID and count columns from the original removals spreadsheet
#group all species ID's by sample and sum the "count" column for each sample x species
removal2<-removal1%>%
  dplyr::select(sample, count, USDA)
#View(removal2)
#verify the # total number of germinants is correct, 5416, CHECK!
sum(removal2$count)

removal3<-removal2%>%
  group_by(sample, USDA)%>%
  summarise_at(vars(count), funs(sum))
#View(removal3)

#verify the # total number of germinants is correct
sum(removal3$count) #5416 check!

#calculate seeds/m2
#convert each "count" to seeds/m2
#20,000 cm3/m2 for a 2 cm depth divided by our total sample size - 169.65 cm3 for a 6 cm by 2 cm core
#create the function(below)
seedstom2<-function(x){
  x*117.9
  
}

#create a new column that multiplies the no. seesd per sample or "count" by the function to give seeds/m2
removal3$seedsm2<-seedstom2(removal3$count)
sum(removal3$count) #yep, check!

#convert this data to "wide" sample by species format
removalwide<-dcast(removal3,sample ~ USDA, value.var = "count")
View(removalwide)

#append the "unique column from att.1 to removal3 so we have all 540 samples plus unique ID
removalwide.1<-full_join(removalwide, enviro.1, by="sample")
View(removalwide.1)

#remove unnecessary columns
removalwide.2<-removalwide.1
removalwide.2$sample <- NULL
removalwide.2$desert<-NULL
removalwide.2$TSF2<-NULL
removalwide.2$overstory<-NULL
removalwide.2$plot_num<-NULL
removalwide.2$burn<-NULL
#remove sample 77
removalwide.2<-removalwide.2[-c(533),]
View(removalwide.2)

#replace all NAs with 0
str(removalwide.2)
removalwide.3<-removalwide.2 %>%
  mutate_at(c(1:90), ~replace(., is.na(.), 0))
#View(removalwide.3)
str(removalwide.3)

#average counts for each UNIQUE (plot x microsite) so we end up with 90 rows
removalwide.4<-removalwide.3%>%
  group_by(unique)%>%
  summarise_all("mean")
View(removalwide.4)


#order the UNIQUE for the diversity matrix and the environmental data so they match
#that way, when we the info back in, it'll match up
removal.final <-removalwide.4[order(removalwide.4$unique),]
#View(removalwide.5)

att.final<-enviro.2[order(enviro.2$unique),]
#View(enviro.3)

View(removal.final)
View(att.final)

######################### Calculate indices  ########################################

#need to convert all columns from numeric to integers
removal.final %>%
  mutate_if(is.numeric,as.integer) 

#shannon diversity
H<-diversity(removal.final[,-1], "shannon")
H
View(H)

#simpsons diversity
S<-diversity(removal.final[,-1], index="simpson")
S
view(S)


#Richness
R<-specnumber(removal.final[,-1])
R
View(R)

#extract the plot num
unique<-removal.final$unique
#View(unique)

#bind the proper sample number with diversity and evenness
removalDIVERSITY.2<-cbind(unique, att.final,R,H,S)
View(removalDIVERSITY.2)



################################### RICHNESS ~ DESERT + overstory #####################

##############CH DENSITY shrub/inter
richdatasetsi.ch<-subset(removalDIVERSITY.2, desert=="CH")
str(richdatasetsi.ch)
View(richdatasetsi.ch)
hist(richdatasetsi.ch$R)
shapiro.test(richdatasetsi.ch$R) #normal
boxplot(R ~ overstory, data = richdatasetsi.ch)
bartlett.test(R ~ overstory, data = richdatasetsi.ch)#homogeneous


#t test with var.eq=T 
t.test(R ~ overstory, data=richdatasetsi.ch, mu=0, alt="two.sided", var.eq=T)#different


chrsimeans<-summarySE(richdatasetsi.ch, measurevar = "R", groupvars = "overstory")
chrsimeans


##############CP DENSITY shrub/inter
richnessdatasetsi.cp<-subset(removalDIVERSITY.2, desert=="CP")
str(richnessdatasetsi.cp)
View(richnessdatasetsi.cp)
hist(richnessdatasetsi.cp$R)
shapiro.test(richnessdatasetsi.cp$R) #normal
boxplot(R ~ overstory, data = richnessdatasetsi.cp)
bartlett.test(R ~ overstory, data = richnessdatasetsi.cp) #homogeneity


#data normal, homogeneity OK..can do a t test with var.eq=t
t.test(R ~ overstory, data=richnessdatasetsi.cp, mu=0, alt="two.sided", var.eq=T)


cpsirmeans<-summarySE(richnessdatasetsi.cp, measurevar = "R", groupvars = "overstory")
cpsirmeans

###################GB DENSITY shrub/inter
richnessdatasetsi.gb<-subset(removalDIVERSITY.2, desert=="GB")
str(richnessdatasetsi.gb)
View(richnessdatasetsi.gb)
hist(richnessdatasetsi.gb$R)
shapiro.test(richnessdatasetsi.gb$R) #normal (barely)
boxplot(R ~ overstory, data = richnessdatasetsi.gb)
bartlett.test(R ~ overstory, data = richnessdatasetsi.gb) #homogeneous


##t test with var.eq=t 
t.test(R ~ overstory, data=richnessdatasetsi.gb, mu=0, alt="two.sided", var.eq=T)
#not sig


gbmeanssir<-summarySE(richnessdatasetsi.gb, measurevar = "R", groupvars = "overstory")
gbmeanssir

####################SO DENSITY shrub/inter
richnessdatasetsi.so<-subset(removalDIVERSITY.2, desert=="SO")
str(richnessdatasetsi.so)
View(richnessdatasetsi.so)
hist(richnessdatasetsi.so$R)
shapiro.test(richnessdatasetsi.so$R) # normal
boxplot(R ~ overstory, data = richnessdatasetsi.so)
bartlett.test(R ~ overstory, data = richnessdatasetsi.so)#homogeneous


#t test with var.eq=T THIS IS THE TEST USED FOR RESULTS!!!!
t.test(R ~ overstory, data=richnessdatasetsi.so, mu=0, alt="two.sided", var.eq=T)
#not sig.


someanssir<-summarySE(richnessdatasetsi.so, measurevar = "R", groupvars = "overstory")
someanssir
