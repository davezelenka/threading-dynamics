#the goal of this script is to compare seed densities by microsite for each desert

setwd()
densitydataset<-read.csv("seedbank_ghousecountdata_density.csv")
attribute<-read.csv("seedbank_attribute_spreadsheet.csv")
View(densitydataset)

library(rcompanion)
#install.packages("FSA")
library(FSA)
library(Rmisc)
#install.packages("dplyr")
library(dplyr)
#install.packages("ggpubr")
library(ggpubr)
#install.packages("pscl")
library(pscl)
library(lmtest)
library(multcompView)
library(multcomp)
#install.packages("emmeans")
library(emmeans)
library(car)
#install.packages("forcats")
library(forcats)
#install.packages("vegan")
library(vegan)


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~DATA PREP~~~~~~~~~~~~~~~~~~~~~~~~~~
#create a unique ID so that we can average by plotXmicrosite level
#and select only the fields that I need
enviro.1<-attribute%>%
  unite(unique, fullplot_name, overstory, sep = "-", remove = FALSE)%>%
  dplyr::select(sample, unique, desert, TSF2, overstory, burn, plot_num)

enviro.2<-enviro.1%>%
  dplyr::select(desert, burn, TSF2, overstory, unique)%>%
  distinct(.)

View(enviro.2)

removal<-densitydataset%>%
  group_by(sample)%>%
  summarise_at(vars(count), funs(sum))

#verify the # total number of germinants is correct
sum(removal$count) #5674 check!

#calculate seeds/m2
#convert each "count" to seeds/m2
#20,000 cm3/m2 for a 2 cm depth divided by our total sample size - 169.65 cm3 for a 6 cm by 2 cm core
#create the function(below)
seedstom2<-function(x){
  x*117.9
  
}

#create a new column that multiplies the no. seesd per sample or "count" by the function to give seeds/m2
removal$seedsm2<-seedstom2(removal$count)
sum(removal$count) #yep, check!


#append the "unique column from att.1 to removal3 so we have all 540 samples plus unique ID
removal2<-full_join(removal, enviro.1, by="sample")
View(removal2)

#remove unnecessary columns
removal3<-removal2
removal3$sample <- NULL
removal3$desert<-NULL
removal3$TSF2<-NULL
removal3$overstory<-NULL
removal3$burn<-NULL
removal3$plot_num<-NULL
#remove sample 77
View(removal3)
removal3<-removal3[-c(535),]
View(removal3)

#replace all NAs with 0
str(removal3)
removal4<-removal3 %>%
  mutate_at(c(1:2), ~replace(., is.na(.), 0))
View(removal4)
str(removal4)

#average counts for each UNIQUE (plot x microsite) so we end up with 90 values
removal5<-removal4%>%
  group_by(unique)%>%
  summarise_at(vars(count, seedsm2), funs(mean))
View(removal5)

#reappend desert and burn info
final.2<-full_join(removal5, enviro.2, by="unique")
View(final.2)

################################### DENSITY ~ DESERT + OVERSTORY #####################

##############CH DENSITY shrub/inter
densitydatasetsi.ch<-subset(final.2, desert=="CH")
str(densitydatasetsi.ch)
View(densitydatasetsi.ch)
hist(densitydatasetsi.ch$seedsm2)
shapiro.test(densitydatasetsi.ch$seedsm2) #NOT normal
boxplot(seedsm2 ~ overstory, data = densitydatasetsi.ch)
fligner.test(seedsm2 ~ overstory, data = densitydatasetsi.ch)#fligner robust against normality, homogeneity, wilcoxon would be OK


#data normal, variance homogeneous
wilcox.test(seedsm2 ~ overstory, data=densitydatasetsi.ch, exact=F) #different


chsimeans<-summarySE(densitydatasetsi.ch, measurevar = "seedsm2", groupvars = "overstory")
chsimeans


##############CP DENSITY shrub/inter
densitydatasetsi.cp<-subset(final.2, desert=="CP")
str(densitydatasetsi.cp)
View(densitydatasetsi.cp)
hist(densitydatasetsi.cp$seedsm2)
shapiro.test(densitydatasetsi.cp$seedsm2) #NOT normal
boxplot(seedsm2 ~ overstory, data = densitydatasetsi.cp)
fligner.test(seedsm2 ~ overstory, data = densitydatasetsi.cp) #homogeneity, wilcoxon OK


wt.cp<-wilcox.test(seedsm2 ~ overstory, data=densitydatasetsi.cp, exact=F)
wt.cp#not different


cpsimeans<-summarySE(densitydatasetsi.cp, measurevar = "seedsm2", groupvars = "overstory")
cpsimeans

###################GB DENSITY shrub/inter
densitydatasetsi.gb<-subset(final.2, desert=="GB")
str(densitydatasetsi.gb)
View(densitydatasetsi.gb)
hist(densitydatasetsi.gb$seedsm2)
shapiro.test(densitydatasetsi.gb$seedsm2) #not normal
boxplot(seedsm2 ~ overstory, data = densitydatasetsi.gb)
fligner.test(seedsm2 ~ overstory, data = densitydatasetsi.gb)#homogeneity!!


wilcox.test(seedsm2 ~ overstory, data=densitydatasetsi.gb, exact=F) # not different!!


gbsimeans<-summarySE(densitydatasetsi.gb, measurevar = "seedsm2", groupvars = "overstory")
gbsimeans

#################### SO DENSITY shrub/inter

densitydatasetsi.so<-subset(final.2, desert=="SO")
str(densitydatasetsi.so)
View(densitydatasetsi.so)
hist(densitydatasetsi.so$seedsm2)
shapiro.test(densitydatasetsi.so$seedsm2) # normal
boxplot(seedsm2 ~ overstory, data = densitydatasetsi.so)
bartlett.test(seedsm2 ~ overstory, data = densitydatasetsi.so)

wilcox.test(seedsm2 ~ overstory, data=densitydatasetsi.so, exact=F) # NO different!


sosimeans<-summarySE(densitydatasetsi.so, measurevar = "seedsm2", groupvars = "overstory")
sosimeans


